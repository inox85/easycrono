﻿namespace TestManager
{
    partial class frmAssegnaArrivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSalva = new System.Windows.Forms.Button();
            this.btnAnnulla = new System.Windows.Forms.Button();
            this.dgvAssegnaArrivi = new System.Windows.Forms.DataGridView();
            this.dgvElencoAtleti = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssegnaArrivi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElencoAtleti)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSalva
            // 
            this.btnSalva.Location = new System.Drawing.Point(407, 389);
            this.btnSalva.Name = "btnSalva";
            this.btnSalva.Size = new System.Drawing.Size(75, 23);
            this.btnSalva.TabIndex = 1;
            this.btnSalva.Text = "Salva";
            this.btnSalva.UseVisualStyleBackColor = true;
            this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
            // 
            // btnAnnulla
            // 
            this.btnAnnulla.Location = new System.Drawing.Point(326, 389);
            this.btnAnnulla.Name = "btnAnnulla";
            this.btnAnnulla.Size = new System.Drawing.Size(75, 23);
            this.btnAnnulla.TabIndex = 2;
            this.btnAnnulla.Text = "Annulla";
            this.btnAnnulla.UseVisualStyleBackColor = true;
            this.btnAnnulla.Click += new System.EventHandler(this.btnAnnulla_Click);
            // 
            // dgvAssegnaArrivi
            // 
            this.dgvAssegnaArrivi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssegnaArrivi.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvAssegnaArrivi.Location = new System.Drawing.Point(12, 12);
            this.dgvAssegnaArrivi.Name = "dgvAssegnaArrivi";
            this.dgvAssegnaArrivi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAssegnaArrivi.Size = new System.Drawing.Size(209, 371);
            this.dgvAssegnaArrivi.TabIndex = 3;
            this.dgvAssegnaArrivi.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAssegnaArrivi_CellContentClick);
            this.dgvAssegnaArrivi.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvAssegnaArrivi_RowsAdded);
            this.dgvAssegnaArrivi.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgvAssegnaArrivi_RowsRemoved);
            // 
            // dgvElencoAtleti
            // 
            this.dgvElencoAtleti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvElencoAtleti.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvElencoAtleti.Location = new System.Drawing.Point(273, 12);
            this.dgvElencoAtleti.Name = "dgvElencoAtleti";
            this.dgvElencoAtleti.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvElencoAtleti.Size = new System.Drawing.Size(209, 371);
            this.dgvElencoAtleti.TabIndex = 4;
            this.dgvElencoAtleti.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvElencoAtleti_CellContentDoubleClick);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(227, 142);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(40, 40);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "<<";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(227, 188);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(40, 40);
            this.btnRemove.TabIndex = 6;
            this.btnRemove.Text = ">>";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // frmAssegnaArrivo
            // 
            this.AcceptButton = this.btnSalva;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 424);
            this.ControlBox = false;
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvElencoAtleti);
            this.Controls.Add(this.dgvAssegnaArrivi);
            this.Controls.Add(this.btnAnnulla);
            this.Controls.Add(this.btnSalva);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmAssegnaArrivo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Assegna ordine d\'arrivo";
            this.Load += new System.EventHandler(this.frmAssegnaArrivo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssegnaArrivi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElencoAtleti)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalva;
        private System.Windows.Forms.Button btnAnnulla;
        private System.Windows.Forms.DataGridView dgvAssegnaArrivi;
        private System.Windows.Forms.DataGridView dgvElencoAtleti;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
    }
}