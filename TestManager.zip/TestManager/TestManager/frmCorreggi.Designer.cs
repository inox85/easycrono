﻿namespace TestManager
{
    partial class frmCorreggi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbSocieta = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCorreggi = new System.Windows.Forms.Button();
            this.cbNome = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbMisura = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbSocieta
            // 
            this.cbSocieta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSocieta.FormattingEnabled = true;
            this.cbSocieta.Location = new System.Drawing.Point(12, 27);
            this.cbSocieta.Name = "cbSocieta";
            this.cbSocieta.Size = new System.Drawing.Size(316, 21);
            this.cbSocieta.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Selezionare Società";
            // 
            // btnCorreggi
            // 
            this.btnCorreggi.Location = new System.Drawing.Point(253, 148);
            this.btnCorreggi.Name = "btnCorreggi";
            this.btnCorreggi.Size = new System.Drawing.Size(75, 23);
            this.btnCorreggi.TabIndex = 7;
            this.btnCorreggi.Text = "Correggi";
            this.btnCorreggi.UseVisualStyleBackColor = true;
            this.btnCorreggi.Click += new System.EventHandler(this.btnCorreggi_Click);
            // 
            // cbNome
            // 
            this.cbNome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNome.FormattingEnabled = true;
            this.cbNome.Location = new System.Drawing.Point(12, 67);
            this.cbNome.Name = "cbNome";
            this.cbNome.Size = new System.Drawing.Size(316, 21);
            this.cbNome.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nome Atleta";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(89, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Metri";
            // 
            // tbMisura
            // 
            this.tbMisura.Location = new System.Drawing.Point(12, 109);
            this.tbMisura.Name = "tbMisura";
            this.tbMisura.Size = new System.Drawing.Size(71, 20);
            this.tbMisura.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Misura";
            // 
            // frmCorreggi
            // 
            this.AcceptButton = this.btnCorreggi;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 183);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbMisura);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbSocieta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCorreggi);
            this.Controls.Add(this.cbNome);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmCorreggi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seleziona informazioni atleta";
            this.Load += new System.EventHandler(this.frmCorreggi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbSocieta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCorreggi;
        private System.Windows.Forms.ComboBox cbNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbMisura;
        private System.Windows.Forms.Label label5;
    }
}