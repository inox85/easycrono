﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;


using NPOI.HSSF.UserModel;
using NPOI.XSSF;
using NPOI.HPSF;
using NPOI.POIFS.FileSystem;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System.IO;

namespace TestManager
{
    public partial class frmBatteria : Form
    {

        public Dictionary<string,string> Batteria;


        public frmBatteria()
        {
            InitializeComponent();
            Batteria = new Dictionary<string, string>();
            
        }

        private void btnAggiungi_Click(object sender, EventArgs e)
        {
            if (tbNome.Text != "")
            {
                dgvBatteria.Rows.Add(tbNome.Text,tbNote.Text);
                tbNome.Text = "";
                tbNote.Text = "";
                tbNome.Focus();
            }
        }

        private void btnRimuovi_Click(object sender, EventArgs e)
        {
            try
            {
                dgvBatteria.Rows.Remove(dgvBatteria.CurrentRow);
            }
            catch
            {

            }
        }

        private void tbNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAggiungi_Click(null, null);
            }
        }

        private void btnConferma_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvBatteria.Rows)
            {
                try
                {
                    Batteria.Add(row.Cells[0].Value.ToString(), (row.Cells[1].Value.ToString()));
                }
                catch
                {

                }
            }

            this.Close();
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        XSSFWorkbook xssfworkbook;

        private void btnLoadExcel_Click(object sender, EventArgs e)
        {
            if(ofdBatteria.ShowDialog() == DialogResult.OK)
            {

                
                try
                {
                    using (FileStream file = new FileStream(ofdBatteria.FileName, FileMode.Open, FileAccess.ReadWrite))
                    {
                        xssfworkbook = new XSSFWorkbook(file);
                        int sheetCount = xssfworkbook.Count;

                        for (int i = 0; i < sheetCount; i++)
                        {
                            cbBatterie.Items.Add(xssfworkbook.GetSheetAt(i).SheetName);
                        }
                        
                        if(cbBatterie.Items.Count > 0)
                        {
                            cbBatterie.SelectedIndex = 0;
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Attenzione: file impostato in sola lettura oppure è aperto.");
                }

               
                
            } 


        }

        private void cbBatterie_SelectedValueChanged(object sender, EventArgs e)
        {
            dgvBatteria.Rows.Clear();

            ISheet sheet = xssfworkbook.GetSheetAt(cbBatterie.SelectedIndex);


            int activeRows = sheet.LastRowNum;
             
            for(int i = 0; i<= activeRows; i++)
            {

                string nomeAlteta = sheet.GetRow(i).GetCell(0).StringCellValue;
                string note = sheet.GetRow(i).GetCell(1).StringCellValue;
                dgvBatteria.Rows.Add(nomeAlteta,note);

            }



        }
    }
}
