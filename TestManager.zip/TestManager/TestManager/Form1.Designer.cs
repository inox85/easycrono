﻿namespace TestManager
{
    partial class FrmMain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.SerialeCronometro = new System.IO.Ports.SerialPort(this.components);
            this.tmrMain = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.tbMisura = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAggiungi = new System.Windows.Forms.Button();
            this.cbNome = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDebug = new System.Windows.Forms.Label();
            this.btnGraphJump = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apriGraficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apriCartellaAtletiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apriCartellaGaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creaCartellaSocietàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modalitàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tracciatoAdAnelloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizzaIntertempiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuovoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atletaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnStorico = new System.Windows.Forms.Button();
            this.ofdAllega = new System.Windows.Forms.OpenFileDialog();
            this.tmrTimeOut = new System.Windows.Forms.Timer(this.components);
            this.cbSocieta = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSaveJumpTest = new System.Windows.Forms.Button();
            this.tabTest = new System.Windows.Forms.TabControl();
            this.tabSpeedTest = new System.Windows.Forms.TabPage();
            this.btnStampa = new System.Windows.Forms.Button();
            this.btnClean = new System.Windows.Forms.Button();
            this.lblTime = new System.Windows.Forms.Label();
            this.btnAssegna = new System.Windows.Forms.Button();
            this.cbBatteria = new System.Windows.Forms.CheckBox();
            this.btnCambiaAtleta = new System.Windows.Forms.Button();
            this.btnAllega = new System.Windows.Forms.Button();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnArchivia = new System.Windows.Forms.Button();
            this.cbReactAndSpeed = new System.Windows.Forms.CheckBox();
            this.pbDownload = new System.Windows.Forms.ProgressBar();
            this.btnReactTime = new System.Windows.Forms.Button();
            this.btnEsporta = new System.Windows.Forms.Button();
            this.bntStop = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.dgvPrestazioni = new System.Windows.Forms.DataGridView();
            this.clmAtleta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmMisura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmTempo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmSocieta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabJumpTest = new System.Windows.Forms.TabPage();
            this.dgvJumpTest = new System.Windows.Forms.DataGridView();
            this.clmSalto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmContatto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmVolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAltezza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmJR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnRstJump = new System.Windows.Forms.Button();
            this.lblJumpTest = new System.Windows.Forms.Label();
            this.tabTestScuola = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnArchiviaTestScuola = new System.Windows.Forms.Button();
            this.dgvTestScuola = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCartella = new System.Windows.Forms.Button();
            this.cbPorts = new System.Windows.Forms.ComboBox();
            this.rbStart = new System.Windows.Forms.RadioButton();
            this.rbStop = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblBatt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSchedaAtleta = new System.Windows.Forms.Button();
            this.pbConnection = new System.Windows.Forms.PictureBox();
            this.printPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.menuStrip1.SuspendLayout();
            this.tabTest.SuspendLayout();
            this.tabSpeedTest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrestazioni)).BeginInit();
            this.tabJumpTest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJumpTest)).BeginInit();
            this.tabTestScuola.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestScuola)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbConnection)).BeginInit();
            this.SuspendLayout();
            // 
            // SerialeCronometro
            // 
            this.SerialeCronometro.BaudRate = 250000;
            this.SerialeCronometro.PortName = "COM5";
            this.SerialeCronometro.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialeCronometro_DataReceived);
            // 
            // tmrMain
            // 
            this.tmrMain.Interval = 94;
            this.tmrMain.Tick += new System.EventHandler(this.tmrMain_Tick);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-240, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Prestazioni ";
            this.label2.Visible = false;
            // 
            // tbNome
            // 
            this.tbNome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbNome.Location = new System.Drawing.Point(792, 288);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(203, 20);
            this.tbNome.TabIndex = 8;
            // 
            // tbMisura
            // 
            this.tbMisura.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbMisura.Location = new System.Drawing.Point(793, 156);
            this.tbMisura.Name = "tbMisura";
            this.tbMisura.Size = new System.Drawing.Size(166, 20);
            this.tbMisura.TabIndex = 9;
            this.tbMisura.Text = "30";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(792, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nome Alteta";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(793, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Misura";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(789, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Nome Atleta";
            // 
            // btnAggiungi
            // 
            this.btnAggiungi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAggiungi.BackColor = System.Drawing.Color.Azure;
            this.btnAggiungi.Location = new System.Drawing.Point(869, 314);
            this.btnAggiungi.Name = "btnAggiungi";
            this.btnAggiungi.Size = new System.Drawing.Size(127, 51);
            this.btnAggiungi.TabIndex = 13;
            this.btnAggiungi.Text = "Aggiungi";
            this.btnAggiungi.UseVisualStyleBackColor = false;
            this.btnAggiungi.Click += new System.EventHandler(this.btnAggiungi_Click);
            // 
            // cbNome
            // 
            this.cbNome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbNome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNome.FormattingEnabled = true;
            this.cbNome.Location = new System.Drawing.Point(792, 116);
            this.cbNome.Name = "cbNome";
            this.cbNome.Size = new System.Drawing.Size(204, 21);
            this.cbNome.TabIndex = 14;
            this.cbNome.Click += new System.EventHandler(this.cbNome_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(965, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Metri";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(928, 497);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Debug";
            this.label7.Visible = false;
            // 
            // lblDebug
            // 
            this.lblDebug.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDebug.AutoSize = true;
            this.lblDebug.Location = new System.Drawing.Point(928, 516);
            this.lblDebug.Name = "lblDebug";
            this.lblDebug.Size = new System.Drawing.Size(10, 13);
            this.lblDebug.TabIndex = 17;
            this.lblDebug.Text = "-";
            this.lblDebug.Visible = false;
            // 
            // btnGraphJump
            // 
            this.btnGraphJump.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGraphJump.BackColor = System.Drawing.Color.Azure;
            this.btnGraphJump.Location = new System.Drawing.Point(30, 541);
            this.btnGraphJump.Name = "btnGraphJump";
            this.btnGraphJump.Size = new System.Drawing.Size(127, 35);
            this.btnGraphJump.TabIndex = 25;
            this.btnGraphJump.Text = "GraphJump";
            this.btnGraphJump.UseVisualStyleBackColor = false;
            this.btnGraphJump.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolsToolStripMenuItem,
            this.modalitàToolStripMenuItem,
            this.nuovoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 29;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.apriGraficoToolStripMenuItem,
            this.apriCartellaAtletiToolStripMenuItem,
            this.apriCartellaGaraToolStripMenuItem,
            this.creaCartellaSocietàToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // apriGraficoToolStripMenuItem
            // 
            this.apriGraficoToolStripMenuItem.Name = "apriGraficoToolStripMenuItem";
            this.apriGraficoToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.apriGraficoToolStripMenuItem.Text = "Apri Grafico";
            this.apriGraficoToolStripMenuItem.Click += new System.EventHandler(this.apriGraficoToolStripMenuItem_Click);
            // 
            // apriCartellaAtletiToolStripMenuItem
            // 
            this.apriCartellaAtletiToolStripMenuItem.Name = "apriCartellaAtletiToolStripMenuItem";
            this.apriCartellaAtletiToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.apriCartellaAtletiToolStripMenuItem.Text = "Apri Cartella Atleti";
            this.apriCartellaAtletiToolStripMenuItem.Click += new System.EventHandler(this.apriCartellaAtletiToolStripMenuItem_Click);
            // 
            // apriCartellaGaraToolStripMenuItem
            // 
            this.apriCartellaGaraToolStripMenuItem.Name = "apriCartellaGaraToolStripMenuItem";
            this.apriCartellaGaraToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.apriCartellaGaraToolStripMenuItem.Text = "Apri Cartella Gara";
            this.apriCartellaGaraToolStripMenuItem.Click += new System.EventHandler(this.apriCartellaGaraToolStripMenuItem_Click);
            // 
            // creaCartellaSocietàToolStripMenuItem
            // 
            this.creaCartellaSocietàToolStripMenuItem.Name = "creaCartellaSocietàToolStripMenuItem";
            this.creaCartellaSocietàToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.creaCartellaSocietàToolStripMenuItem.Text = "Crea Cartella Società/Scuola";
            this.creaCartellaSocietàToolStripMenuItem.Click += new System.EventHandler(this.creaCartellaSocietàToolStripMenuItem_Click);
            // 
            // modalitàToolStripMenuItem
            // 
            this.modalitàToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tracciatoAdAnelloToolStripMenuItem,
            this.visualizzaIntertempiToolStripMenuItem});
            this.modalitàToolStripMenuItem.Name = "modalitàToolStripMenuItem";
            this.modalitàToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.modalitàToolStripMenuItem.Text = "Modalità";
            // 
            // tracciatoAdAnelloToolStripMenuItem
            // 
            this.tracciatoAdAnelloToolStripMenuItem.CheckOnClick = true;
            this.tracciatoAdAnelloToolStripMenuItem.Name = "tracciatoAdAnelloToolStripMenuItem";
            this.tracciatoAdAnelloToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.tracciatoAdAnelloToolStripMenuItem.Text = "Tracciato ad anello (una sola fotocellula)";
            this.tracciatoAdAnelloToolStripMenuItem.CheckedChanged += new System.EventHandler(this.tracciatoAdAnelloToolStripMenuItem_CheckedChanged);
            this.tracciatoAdAnelloToolStripMenuItem.Click += new System.EventHandler(this.tracciatoAdAnelloToolStripMenuItem_Click);
            // 
            // visualizzaIntertempiToolStripMenuItem
            // 
            this.visualizzaIntertempiToolStripMenuItem.CheckOnClick = true;
            this.visualizzaIntertempiToolStripMenuItem.Name = "visualizzaIntertempiToolStripMenuItem";
            this.visualizzaIntertempiToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.visualizzaIntertempiToolStripMenuItem.Text = "Visualizza Intertempi";
            // 
            // nuovoToolStripMenuItem
            // 
            this.nuovoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.atletaToolStripMenuItem});
            this.nuovoToolStripMenuItem.Name = "nuovoToolStripMenuItem";
            this.nuovoToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.nuovoToolStripMenuItem.Text = "Nuovo";
            this.nuovoToolStripMenuItem.Visible = false;
            // 
            // atletaToolStripMenuItem
            // 
            this.atletaToolStripMenuItem.Name = "atletaToolStripMenuItem";
            this.atletaToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.atletaToolStripMenuItem.Text = "Atleta";
            this.atletaToolStripMenuItem.Click += new System.EventHandler(this.atletaToolStripMenuItem_Click);
            // 
            // btnStorico
            // 
            this.btnStorico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStorico.BackColor = System.Drawing.Color.Azure;
            this.btnStorico.Location = new System.Drawing.Point(895, 191);
            this.btnStorico.Name = "btnStorico";
            this.btnStorico.Size = new System.Drawing.Size(102, 36);
            this.btnStorico.TabIndex = 32;
            this.btnStorico.Text = "Apri Storico";
            this.btnStorico.UseVisualStyleBackColor = false;
            this.btnStorico.Click += new System.EventHandler(this.btnStorico_Click);
            // 
            // ofdAllega
            // 
            this.ofdAllega.FileName = "openFileDialog1";
            // 
            // tmrTimeOut
            // 
            this.tmrTimeOut.Interval = 1000;
            this.tmrTimeOut.Tick += new System.EventHandler(this.tmrTimeOut_Tick);
            // 
            // cbSocieta
            // 
            this.cbSocieta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSocieta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSocieta.FormattingEnabled = true;
            this.cbSocieta.Location = new System.Drawing.Point(792, 76);
            this.cbSocieta.Name = "cbSocieta";
            this.cbSocieta.Size = new System.Drawing.Size(204, 21);
            this.cbSocieta.TabIndex = 39;
            this.cbSocieta.SelectedIndexChanged += new System.EventHandler(this.cbSocieta_SelectedIndexChanged);
            this.cbSocieta.Click += new System.EventHandler(this.cbSocieta_Click);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(792, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 38;
            this.label8.Text = "Società/Scuola";
            // 
            // btnSaveJumpTest
            // 
            this.btnSaveJumpTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveJumpTest.BackColor = System.Drawing.Color.Azure;
            this.btnSaveJumpTest.Location = new System.Drawing.Point(628, 421);
            this.btnSaveJumpTest.MinimumSize = new System.Drawing.Size(127, 35);
            this.btnSaveJumpTest.Name = "btnSaveJumpTest";
            this.btnSaveJumpTest.Size = new System.Drawing.Size(127, 35);
            this.btnSaveJumpTest.TabIndex = 36;
            this.btnSaveJumpTest.Text = "Archivia";
            this.btnSaveJumpTest.UseVisualStyleBackColor = false;
            this.btnSaveJumpTest.Click += new System.EventHandler(this.btnSaveJumpTest_Click);
            // 
            // tabTest
            // 
            this.tabTest.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabTest.Controls.Add(this.tabSpeedTest);
            this.tabTest.Controls.Add(this.tabJumpTest);
            this.tabTest.Controls.Add(this.tabTestScuola);
            this.tabTest.Location = new System.Drawing.Point(12, 29);
            this.tabTest.Name = "tabTest";
            this.tabTest.SelectedIndex = 0;
            this.tabTest.Size = new System.Drawing.Size(769, 488);
            this.tabTest.TabIndex = 44;
            this.tabTest.SelectedIndexChanged += new System.EventHandler(this.tabTest_SelectedIndexChanged);
            // 
            // tabSpeedTest
            // 
            this.tabSpeedTest.Controls.Add(this.btnStampa);
            this.tabSpeedTest.Controls.Add(this.btnClean);
            this.tabSpeedTest.Controls.Add(this.lblTime);
            this.tabSpeedTest.Controls.Add(this.btnAssegna);
            this.tabSpeedTest.Controls.Add(this.cbBatteria);
            this.tabSpeedTest.Controls.Add(this.btnCambiaAtleta);
            this.tabSpeedTest.Controls.Add(this.btnAllega);
            this.tabSpeedTest.Controls.Add(this.btnElimina);
            this.tabSpeedTest.Controls.Add(this.btnArchivia);
            this.tabSpeedTest.Controls.Add(this.cbReactAndSpeed);
            this.tabSpeedTest.Controls.Add(this.pbDownload);
            this.tabSpeedTest.Controls.Add(this.btnReactTime);
            this.tabSpeedTest.Controls.Add(this.btnEsporta);
            this.tabSpeedTest.Controls.Add(this.bntStop);
            this.tabSpeedTest.Controls.Add(this.btnReset);
            this.tabSpeedTest.Controls.Add(this.btnStart);
            this.tabSpeedTest.Controls.Add(this.label2);
            this.tabSpeedTest.Controls.Add(this.dgvPrestazioni);
            this.tabSpeedTest.Location = new System.Drawing.Point(4, 22);
            this.tabSpeedTest.Name = "tabSpeedTest";
            this.tabSpeedTest.Padding = new System.Windows.Forms.Padding(3);
            this.tabSpeedTest.Size = new System.Drawing.Size(761, 462);
            this.tabSpeedTest.TabIndex = 1;
            this.tabSpeedTest.Text = "Speed Test";
            this.tabSpeedTest.UseVisualStyleBackColor = true;
            // 
            // btnStampa
            // 
            this.btnStampa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStampa.Location = new System.Drawing.Point(652, 339);
            this.btnStampa.Name = "btnStampa";
            this.btnStampa.Size = new System.Drawing.Size(91, 34);
            this.btnStampa.TabIndex = 60;
            this.btnStampa.Text = "Stampa";
            this.btnStampa.UseVisualStyleBackColor = true;
            this.btnStampa.Click += new System.EventHandler(this.btnStampa_Click);
            // 
            // btnClean
            // 
            this.btnClean.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClean.BackColor = System.Drawing.Color.Azure;
            this.btnClean.Location = new System.Drawing.Point(154, 338);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(127, 35);
            this.btnClean.TabIndex = 59;
            this.btnClean.Text = "Elimina tutte le righe";
            this.btnClean.UseVisualStyleBackColor = false;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(13, 18);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(320, 73);
            this.lblTime.TabIndex = 58;
            this.lblTime.Text = "00:00:000";
            // 
            // btnAssegna
            // 
            this.btnAssegna.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAssegna.BackColor = System.Drawing.Color.Azure;
            this.btnAssegna.Location = new System.Drawing.Point(21, 338);
            this.btnAssegna.Name = "btnAssegna";
            this.btnAssegna.Size = new System.Drawing.Size(127, 35);
            this.btnAssegna.TabIndex = 57;
            this.btnAssegna.Text = "Assegna Arrivo";
            this.btnAssegna.UseVisualStyleBackColor = false;
            this.btnAssegna.Visible = false;
            this.btnAssegna.Click += new System.EventHandler(this.btnAssegna_Click);
            // 
            // cbBatteria
            // 
            this.cbBatteria.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbBatteria.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbBatteria.Location = new System.Drawing.Point(21, 297);
            this.cbBatteria.Name = "cbBatteria";
            this.cbBatteria.Size = new System.Drawing.Size(127, 35);
            this.cbBatteria.TabIndex = 56;
            this.cbBatteria.Text = "Modo Batteria";
            this.cbBatteria.UseVisualStyleBackColor = true;
            this.cbBatteria.CheckedChanged += new System.EventHandler(this.cbBatteria_CheckedChanged);
            // 
            // btnCambiaAtleta
            // 
            this.btnCambiaAtleta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCambiaAtleta.BackColor = System.Drawing.Color.Azure;
            this.btnCambiaAtleta.Location = new System.Drawing.Point(286, 297);
            this.btnCambiaAtleta.Name = "btnCambiaAtleta";
            this.btnCambiaAtleta.Size = new System.Drawing.Size(127, 35);
            this.btnCambiaAtleta.TabIndex = 55;
            this.btnCambiaAtleta.Text = "Correggi";
            this.btnCambiaAtleta.UseVisualStyleBackColor = false;
            this.btnCambiaAtleta.Click += new System.EventHandler(this.btnCambiaAtleta_Click);
            // 
            // btnAllega
            // 
            this.btnAllega.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAllega.BackColor = System.Drawing.Color.Azure;
            this.btnAllega.Location = new System.Drawing.Point(419, 297);
            this.btnAllega.Name = "btnAllega";
            this.btnAllega.Size = new System.Drawing.Size(127, 35);
            this.btnAllega.TabIndex = 54;
            this.btnAllega.Text = "Allega Nome File";
            this.btnAllega.UseVisualStyleBackColor = false;
            this.btnAllega.Click += new System.EventHandler(this.btnAllega_Click);
            // 
            // btnElimina
            // 
            this.btnElimina.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnElimina.BackColor = System.Drawing.Color.Azure;
            this.btnElimina.Location = new System.Drawing.Point(153, 297);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(127, 35);
            this.btnElimina.TabIndex = 52;
            this.btnElimina.Text = "Elimina Riga";
            this.btnElimina.UseVisualStyleBackColor = false;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnArchivia
            // 
            this.btnArchivia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnArchivia.BackColor = System.Drawing.Color.Azure;
            this.btnArchivia.Location = new System.Drawing.Point(552, 297);
            this.btnArchivia.Name = "btnArchivia";
            this.btnArchivia.Size = new System.Drawing.Size(191, 35);
            this.btnArchivia.TabIndex = 51;
            this.btnArchivia.Text = "Archivia";
            this.btnArchivia.UseVisualStyleBackColor = false;
            this.btnArchivia.Click += new System.EventHandler(this.btnArchivia_Click);
            // 
            // cbReactAndSpeed
            // 
            this.cbReactAndSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbReactAndSpeed.AutoSize = true;
            this.cbReactAndSpeed.Location = new System.Drawing.Point(420, 381);
            this.cbReactAndSpeed.Name = "cbReactAndSpeed";
            this.cbReactAndSpeed.Size = new System.Drawing.Size(114, 17);
            this.cbReactAndSpeed.TabIndex = 50;
            this.cbReactAndSpeed.Text = "Reazione + Speed";
            this.cbReactAndSpeed.UseVisualStyleBackColor = true;
            // 
            // pbDownload
            // 
            this.pbDownload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbDownload.Location = new System.Drawing.Point(552, 398);
            this.pbDownload.Maximum = 300;
            this.pbDownload.Name = "pbDownload";
            this.pbDownload.Size = new System.Drawing.Size(191, 51);
            this.pbDownload.TabIndex = 49;
            // 
            // btnReactTime
            // 
            this.btnReactTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReactTime.BackColor = System.Drawing.Color.Azure;
            this.btnReactTime.Location = new System.Drawing.Point(420, 398);
            this.btnReactTime.Name = "btnReactTime";
            this.btnReactTime.Size = new System.Drawing.Size(127, 51);
            this.btnReactTime.TabIndex = 48;
            this.btnReactTime.Text = "Start React Time";
            this.btnReactTime.UseVisualStyleBackColor = false;
            this.btnReactTime.Click += new System.EventHandler(this.btnReactTime_Click);
            // 
            // btnEsporta
            // 
            this.btnEsporta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEsporta.BackColor = System.Drawing.Color.Azure;
            this.btnEsporta.Location = new System.Drawing.Point(552, 338);
            this.btnEsporta.Name = "btnEsporta";
            this.btnEsporta.Size = new System.Drawing.Size(94, 35);
            this.btnEsporta.TabIndex = 47;
            this.btnEsporta.Text = "Esporta";
            this.btnEsporta.UseVisualStyleBackColor = false;
            this.btnEsporta.Visible = false;
            this.btnEsporta.Click += new System.EventHandler(this.btnEsporta_Click);
            // 
            // bntStop
            // 
            this.bntStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bntStop.BackColor = System.Drawing.Color.Azure;
            this.bntStop.Location = new System.Drawing.Point(154, 398);
            this.bntStop.Name = "bntStop";
            this.bntStop.Size = new System.Drawing.Size(127, 51);
            this.bntStop.TabIndex = 46;
            this.bntStop.Text = "Stop";
            this.bntStop.UseVisualStyleBackColor = false;
            this.bntStop.Click += new System.EventHandler(this.bntStop_Click);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.BackColor = System.Drawing.Color.Azure;
            this.btnReset.Location = new System.Drawing.Point(287, 398);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(127, 51);
            this.btnReset.TabIndex = 45;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.BackColor = System.Drawing.Color.Azure;
            this.btnStart.Location = new System.Drawing.Point(21, 398);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(127, 51);
            this.btnStart.TabIndex = 44;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // dgvPrestazioni
            // 
            this.dgvPrestazioni.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPrestazioni.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrestazioni.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmAtleta,
            this.clmMisura,
            this.clmTempo,
            this.clmNote,
            this.clmSocieta});
            this.dgvPrestazioni.Location = new System.Drawing.Point(6, 94);
            this.dgvPrestazioni.MultiSelect = false;
            this.dgvPrestazioni.Name = "dgvPrestazioni";
            this.dgvPrestazioni.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrestazioni.Size = new System.Drawing.Size(749, 197);
            this.dgvPrestazioni.TabIndex = 28;
            // 
            // clmAtleta
            // 
            this.clmAtleta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmAtleta.HeaderText = "Atleta";
            this.clmAtleta.Name = "clmAtleta";
            this.clmAtleta.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.clmAtleta.Width = 59;
            // 
            // clmMisura
            // 
            this.clmMisura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmMisura.HeaderText = "Misura";
            this.clmMisura.Name = "clmMisura";
            this.clmMisura.ReadOnly = true;
            this.clmMisura.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.clmMisura.Width = 63;
            // 
            // clmTempo
            // 
            this.clmTempo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmTempo.HeaderText = "Tempo";
            this.clmTempo.Name = "clmTempo";
            this.clmTempo.ReadOnly = true;
            this.clmTempo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.clmTempo.Width = 65;
            // 
            // clmNote
            // 
            this.clmNote.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmNote.HeaderText = "Note";
            this.clmNote.Name = "clmNote";
            this.clmNote.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.clmNote.Width = 55;
            // 
            // clmSocieta
            // 
            this.clmSocieta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmSocieta.HeaderText = "Società";
            this.clmSocieta.Name = "clmSocieta";
            this.clmSocieta.ReadOnly = true;
            this.clmSocieta.Width = 68;
            // 
            // tabJumpTest
            // 
            this.tabJumpTest.Controls.Add(this.dgvJumpTest);
            this.tabJumpTest.Controls.Add(this.btnRstJump);
            this.tabJumpTest.Controls.Add(this.lblJumpTest);
            this.tabJumpTest.Controls.Add(this.btnGraphJump);
            this.tabJumpTest.Controls.Add(this.btnSaveJumpTest);
            this.tabJumpTest.Location = new System.Drawing.Point(4, 22);
            this.tabJumpTest.Name = "tabJumpTest";
            this.tabJumpTest.Padding = new System.Windows.Forms.Padding(3);
            this.tabJumpTest.Size = new System.Drawing.Size(761, 462);
            this.tabJumpTest.TabIndex = 0;
            this.tabJumpTest.Text = "Jump Test";
            this.tabJumpTest.UseVisualStyleBackColor = true;
            // 
            // dgvJumpTest
            // 
            this.dgvJumpTest.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvJumpTest.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvJumpTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJumpTest.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmSalto,
            this.clmContatto,
            this.clmVolo,
            this.clmAltezza,
            this.clmJR});
            this.dgvJumpTest.Location = new System.Drawing.Point(6, 69);
            this.dgvJumpTest.Name = "dgvJumpTest";
            this.dgvJumpTest.Size = new System.Drawing.Size(749, 346);
            this.dgvJumpTest.TabIndex = 36;
            // 
            // clmSalto
            // 
            this.clmSalto.HeaderText = "Salto";
            this.clmSalto.Name = "clmSalto";
            this.clmSalto.Width = 56;
            // 
            // clmContatto
            // 
            this.clmContatto.HeaderText = "Contatto";
            this.clmContatto.Name = "clmContatto";
            this.clmContatto.Width = 72;
            // 
            // clmVolo
            // 
            this.clmVolo.HeaderText = "Volo";
            this.clmVolo.Name = "clmVolo";
            this.clmVolo.Width = 53;
            // 
            // clmAltezza
            // 
            this.clmAltezza.HeaderText = "Altezza";
            this.clmAltezza.Name = "clmAltezza";
            this.clmAltezza.Width = 66;
            // 
            // clmJR
            // 
            this.clmJR.HeaderText = "JR";
            this.clmJR.Name = "clmJR";
            this.clmJR.Width = 45;
            // 
            // btnRstJump
            // 
            this.btnRstJump.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRstJump.BackColor = System.Drawing.Color.Azure;
            this.btnRstJump.Location = new System.Drawing.Point(628, 12);
            this.btnRstJump.Name = "btnRstJump";
            this.btnRstJump.Size = new System.Drawing.Size(127, 51);
            this.btnRstJump.TabIndex = 21;
            this.btnRstJump.Text = "Inizia Jump Test";
            this.btnRstJump.UseVisualStyleBackColor = false;
            this.btnRstJump.Click += new System.EventHandler(this.btnRstJump_Click);
            // 
            // lblJumpTest
            // 
            this.lblJumpTest.AutoSize = true;
            this.lblJumpTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJumpTest.Location = new System.Drawing.Point(6, 42);
            this.lblJumpTest.Name = "lblJumpTest";
            this.lblJumpTest.Size = new System.Drawing.Size(351, 20);
            this.lblJumpTest.TabIndex = 19;
            this.lblJumpTest.Text = "Premere \"Inizia Jump Test\" e seguire le istruzioni";
            // 
            // tabTestScuola
            // 
            this.tabTestScuola.Controls.Add(this.button3);
            this.tabTestScuola.Controls.Add(this.button1);
            this.tabTestScuola.Controls.Add(this.button2);
            this.tabTestScuola.Controls.Add(this.btnArchiviaTestScuola);
            this.tabTestScuola.Controls.Add(this.dgvTestScuola);
            this.tabTestScuola.Location = new System.Drawing.Point(4, 22);
            this.tabTestScuola.Name = "tabTestScuola";
            this.tabTestScuola.Padding = new System.Windows.Forms.Padding(3);
            this.tabTestScuola.Size = new System.Drawing.Size(761, 462);
            this.tabTestScuola.TabIndex = 2;
            this.tabTestScuola.Text = "Test Scuola";
            this.tabTestScuola.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.Azure;
            this.button3.Location = new System.Drawing.Point(431, 392);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(127, 35);
            this.button3.TabIndex = 55;
            this.button3.Text = "Elimina Riga";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Azure;
            this.button1.Location = new System.Drawing.Point(154, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 51);
            this.button1.TabIndex = 54;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.Azure;
            this.button2.Location = new System.Drawing.Point(21, 398);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 51);
            this.button2.TabIndex = 53;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnArchiviaTestScuola
            // 
            this.btnArchiviaTestScuola.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnArchiviaTestScuola.BackColor = System.Drawing.Color.Azure;
            this.btnArchiviaTestScuola.Location = new System.Drawing.Point(564, 392);
            this.btnArchiviaTestScuola.Name = "btnArchiviaTestScuola";
            this.btnArchiviaTestScuola.Size = new System.Drawing.Size(191, 35);
            this.btnArchiviaTestScuola.TabIndex = 52;
            this.btnArchiviaTestScuola.Text = "Archivia Test Scuola";
            this.btnArchiviaTestScuola.UseVisualStyleBackColor = false;
            this.btnArchiviaTestScuola.Click += new System.EventHandler(this.btnArchiviaTestScuola_Click);
            // 
            // dgvTestScuola
            // 
            this.dgvTestScuola.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTestScuola.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTestScuola.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgvTestScuola.Location = new System.Drawing.Point(6, 9);
            this.dgvTestScuola.MultiSelect = false;
            this.dgvTestScuola.Name = "dgvTestScuola";
            this.dgvTestScuola.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTestScuola.Size = new System.Drawing.Size(749, 377);
            this.dgvTestScuola.TabIndex = 29;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Atleta";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Misura";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Tempo";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.HeaderText = "Note";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.Width = 55;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Società";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // btnCartella
            // 
            this.btnCartella.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCartella.BackColor = System.Drawing.Color.Azure;
            this.btnCartella.Location = new System.Drawing.Point(895, 233);
            this.btnCartella.Name = "btnCartella";
            this.btnCartella.Size = new System.Drawing.Size(102, 36);
            this.btnCartella.TabIndex = 34;
            this.btnCartella.Text = "Apri Cartella";
            this.btnCartella.UseVisualStyleBackColor = false;
            this.btnCartella.Click += new System.EventHandler(this.btnCartella_Click);
            // 
            // cbPorts
            // 
            this.cbPorts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPorts.FormattingEnabled = true;
            this.cbPorts.Location = new System.Drawing.Point(895, 29);
            this.cbPorts.Name = "cbPorts";
            this.cbPorts.Size = new System.Drawing.Size(75, 21);
            this.cbPorts.TabIndex = 49;
            this.cbPorts.SelectedIndexChanged += new System.EventHandler(this.cbPorts_SelectedIndexChanged);
            this.cbPorts.Click += new System.EventHandler(this.cbPorts_Click);
            // 
            // rbStart
            // 
            this.rbStart.AutoSize = true;
            this.rbStart.Checked = true;
            this.rbStart.Location = new System.Drawing.Point(11, 19);
            this.rbStart.Name = "rbStart";
            this.rbStart.Size = new System.Drawing.Size(47, 17);
            this.rbStart.TabIndex = 50;
            this.rbStart.TabStop = true;
            this.rbStart.Text = "Start";
            this.rbStart.UseVisualStyleBackColor = true;
            // 
            // rbStop
            // 
            this.rbStop.AutoSize = true;
            this.rbStop.Location = new System.Drawing.Point(11, 42);
            this.rbStop.Name = "rbStop";
            this.rbStop.Size = new System.Drawing.Size(47, 17);
            this.rbStop.TabIndex = 51;
            this.rbStop.Text = "Stop";
            this.rbStop.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lblBatt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.rbStart);
            this.groupBox1.Controls.Add(this.rbStop);
            this.groupBox1.Location = new System.Drawing.Point(793, 371);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(202, 123);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Fotocellula Wireless";
            this.groupBox1.Visible = false;
            // 
            // lblBatt
            // 
            this.lblBatt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBatt.AutoSize = true;
            this.lblBatt.Location = new System.Drawing.Point(63, 65);
            this.lblBatt.Name = "lblBatt";
            this.lblBatt.Size = new System.Drawing.Size(16, 13);
            this.lblBatt.TabIndex = 56;
            this.lblBatt.Text = "---";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 55;
            this.label1.Text = "Batteria: ";
            // 
            // btnSchedaAtleta
            // 
            this.btnSchedaAtleta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSchedaAtleta.BackColor = System.Drawing.Color.Azure;
            this.btnSchedaAtleta.Location = new System.Drawing.Point(793, 233);
            this.btnSchedaAtleta.Name = "btnSchedaAtleta";
            this.btnSchedaAtleta.Size = new System.Drawing.Size(96, 36);
            this.btnSchedaAtleta.TabIndex = 53;
            this.btnSchedaAtleta.Text = "Apri Scheda Atleta";
            this.btnSchedaAtleta.UseVisualStyleBackColor = false;
            this.btnSchedaAtleta.Click += new System.EventHandler(this.btnSchedaAtleta_Click);
            // 
            // pbConnection
            // 
            this.pbConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbConnection.Location = new System.Drawing.Point(976, 29);
            this.pbConnection.Name = "pbConnection";
            this.pbConnection.Size = new System.Drawing.Size(21, 21);
            this.pbConnection.TabIndex = 54;
            this.pbConnection.TabStop = false;
            // 
            // printPreview
            // 
            this.printPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview.Enabled = true;
            this.printPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview.Icon")));
            this.printPreview.Name = "printPreviewDialog1";
            this.printPreview.Visible = false;
            // 
            // printDocument
            // 
            this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 537);
            this.Controls.Add(this.pbConnection);
            this.Controls.Add(this.btnSchedaAtleta);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbPorts);
            this.Controls.Add(this.tabTest);
            this.Controls.Add(this.cbSocieta);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnCartella);
            this.Controls.Add(this.btnStorico);
            this.Controls.Add(this.lblDebug);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbNome);
            this.Controls.Add(this.btnAggiungi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbMisura);
            this.Controls.Add(this.tbNome);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TestManager";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabTest.ResumeLayout(false);
            this.tabSpeedTest.ResumeLayout(false);
            this.tabSpeedTest.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrestazioni)).EndInit();
            this.tabJumpTest.ResumeLayout(false);
            this.tabJumpTest.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJumpTest)).EndInit();
            this.tabTestScuola.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestScuola)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbConnection)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort SerialeCronometro;
        private System.Windows.Forms.Timer tmrMain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.TextBox tbMisura;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAggiungi;
        private System.Windows.Forms.ComboBox cbNome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblDebug;
        private System.Windows.Forms.Button btnGraphJump;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apriGraficoToolStripMenuItem;
        private System.Windows.Forms.Button btnStorico;
        private System.Windows.Forms.OpenFileDialog ofdAllega;
        private System.Windows.Forms.ToolStripMenuItem apriCartellaAtletiToolStripMenuItem;
        private System.Windows.Forms.Timer tmrTimeOut;
        private System.Windows.Forms.ComboBox cbSocieta;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolStripMenuItem creaCartellaSocietàToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apriCartellaGaraToolStripMenuItem;
        private System.Windows.Forms.Button btnSaveJumpTest;
        private System.Windows.Forms.TabControl tabTest;
        private System.Windows.Forms.TabPage tabJumpTest;
        private System.Windows.Forms.DataGridView dgvJumpTest;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmSalto;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmContatto;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmVolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAltezza;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmJR;
        private System.Windows.Forms.Button btnRstJump;
        private System.Windows.Forms.Label lblJumpTest;
        private System.Windows.Forms.TabPage tabSpeedTest;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button btnAssegna;
        private System.Windows.Forms.CheckBox cbBatteria;
        private System.Windows.Forms.Button btnCambiaAtleta;
        private System.Windows.Forms.Button btnAllega;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnArchivia;
        private System.Windows.Forms.CheckBox cbReactAndSpeed;
        private System.Windows.Forms.ProgressBar pbDownload;
        private System.Windows.Forms.Button btnReactTime;
        private System.Windows.Forms.Button btnEsporta;
        private System.Windows.Forms.Button bntStop;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.DataGridView dgvPrestazioni;
        private System.Windows.Forms.TabPage tabTestScuola;
        private System.Windows.Forms.DataGridView dgvTestScuola;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button btnArchiviaTestScuola;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnCartella;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAtleta;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMisura;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmTempo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmSocieta;
        private System.Windows.Forms.ComboBox cbPorts;
        private System.Windows.Forms.RadioButton rbStart;
        private System.Windows.Forms.RadioButton rbStop;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripMenuItem modalitàToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tracciatoAdAnelloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizzaIntertempiToolStripMenuItem;
        private System.Windows.Forms.Button btnSchedaAtleta;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.PictureBox pbConnection;
        private System.Windows.Forms.ToolStripMenuItem nuovoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atletaToolStripMenuItem;
        private System.Windows.Forms.Label lblBatt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStampa;
        private System.Windows.Forms.PrintPreviewDialog printPreview;
        private System.Drawing.Printing.PrintDocument printDocument;
    }
}

