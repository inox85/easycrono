﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmBmp : Form
    {
        public frmBmp(Bitmap bmp)
        {
            InitializeComponent();
            pictureBox1.Image = bmp;
        }
    }
}
