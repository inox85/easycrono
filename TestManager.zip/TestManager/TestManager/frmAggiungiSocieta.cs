﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmAggiungiSocieta : Form
    {
        public frmAggiungiSocieta()
        {
            InitializeComponent();
        }

        private void btnAggiungi_Click(object sender, EventArgs e)
        {
            Archiviazione.DirectoryExistAndCreate(Archiviazione.GetCartellaSocieta(tbNomeSocieta.Text));
            this.Close();
        }
    }
}
