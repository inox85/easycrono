﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmAssegnaArrivo : Form
    {
        public Dictionary<string,string> Arrivi = new Dictionary<string,string>();
        Dictionary<string, string> Atleti = new Dictionary<string, string>();
        Dictionary<string, string> tempAtleti = new Dictionary<string, string>();
        
     
        DataGridViewComboBoxColumn cbNarrive = new DataGridViewComboBoxColumn();



        public frmAssegnaArrivo(DataGridView dgvPrestazioni, Dictionary<string,string> _atleti)
        {
            InitializeComponent();
            dgvAssegnaArrivi.Rows.Clear();
            cbNarrive.HeaderText = "Atleta";

            Atleti = _atleti;
            tempAtleti = _atleti;
            cbNarrive.DataSource = Atleti.Keys.ToList();

            //dgvAssegnaArrivi.Columns.Add(cbNarrive);

            dgvElencoAtleti.Columns.Add("clmNomeAtleti", "Atleta");

            dgvElencoAtleti.Columns.Add("clmNote", "Note");

            dgvElencoAtleti.ReadOnly = true;

            dgvAssegnaArrivi.Columns.Add("clmNomeAtleti", "Atleta");

            dgvAssegnaArrivi.Columns.Add("clmNote", "Note");

            dgvAssegnaArrivi.ReadOnly = true;

            foreach (KeyValuePair<string,string> kvp in _atleti)
            {
                dgvElencoAtleti.Rows.Add(kvp.Key, kvp.Value);
                
            }

            //foreach (DataGridViewRow row in dgvPrestazioni.Rows)
            //{
            //    dgvAssegnaArrivi.Rows.Add();
            //}

            
            AcceptButton.DialogResult = DialogResult.OK;
        }

        private void frmAssegnaArrivo_Load(object sender, EventArgs e)
        {

        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSalva_Click(object sender, EventArgs e)
        {    
            foreach (DataGridViewRow row in dgvAssegnaArrivi.Rows)
            {
                try
                {
                    if (row.Cells[0].Value.ToString() != "")
                    {

                        Arrivi.Add(row.Cells[0].Value.ToString(), Atleti[row.Cells[0].Value.ToString()]);

                    }
                }
                catch
                {

                }
            }
        }

 

        private void dgvElencoAtleti_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            addArrivo();
            
        }

        private void dgvAssegnaArrivi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            removeArrivo();
        }

        private void dgvAssegnaArrivi_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

            foreach (DataGridViewRow row in dgvAssegnaArrivi.Rows)
            {
                row.HeaderCell.Value = String.Format("{0}", row.Index + 1);
            }
        }

        private void dgvAssegnaArrivi_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            foreach (DataGridViewRow row in dgvAssegnaArrivi.Rows)
            {
                row.HeaderCell.Value = String.Format("{0}", row.Index + 1);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addArrivo();
        }


        private void addArrivo()
        {
            try
            {
                DataGridViewRow row = dgvElencoAtleti.CurrentRow;

                dgvAssegnaArrivi.Rows.Add(row.Cells[0].Value, row.Cells[1].Value);

                dgvElencoAtleti.Rows.RemoveAt(row.Index);

                dgvAssegnaArrivi.Update();
            }
            catch
            {
               
            }

        }


        private void removeArrivo()
        {
            try
            {
                DataGridViewRow row = dgvAssegnaArrivi.CurrentRow;

                dgvElencoAtleti.Rows.Add(row.Cells[0].Value, row.Cells[1].Value);

                dgvAssegnaArrivi.Rows.RemoveAt(row.Index);

                dgvElencoAtleti.Update();
            }
            catch
            {

            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            removeArrivo();
        }
    }
}
