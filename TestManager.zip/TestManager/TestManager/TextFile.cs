﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using System.Windows.Forms;

namespace TestManager
{
    class TextFile
    {
        string Text;
        string Percorso;
        public ArrayList StringList;
       
        public TextFile(string Path)
        {

        StringList = new ArrayList();
        
        try
            {
                Text = File.ReadAllText(Path);
                StringList = GetStringsArray();
                Percorso = Path;
            }
            catch (Exception ex)
            {
                //File.Create(Path);
                //Text = File.ReadAllText(Path);
                //StringList = GetStringsArray();
                Percorso = Path;
               
            }
        }

        public string[] Strings
        {
            get
            {
                return Text.Replace("\r","").Split('\n');
            }
        }


        private ArrayList GetStringsArray()
        {
            ArrayList StringList = new ArrayList();

            foreach (string s in Strings)
            {
                if (s != "" && s != null)
                {
                    StringList.Add(s);
                }
            }

            return StringList;

        }

        public void ClearTextFile()
        {
            File.WriteAllText(Percorso, "");
        }
        public void WriteTextToFile(string Text)
        {
            File.WriteAllText(Percorso, Text);
        }

        public void WriteTextToFile(string Path,string Text)
        {
            File.WriteAllText(Path, Text);
        }
        public void AddToFile(string Riga){

            StringList.Add(Riga);           
        }
        public void AddToFile(string[] Righe)
        {
            foreach (string s in Righe)
            {
                StringList.Add(s);
            }
        
        }

        public void AddToFileAndWrite(string[] Righe)
        {
            foreach (string s in Righe)
            {
                StringList.Add(s);
            }
            WriteToFile();
        }

        public void AddToFileAndWrite(string Riga)
        {
            StringList.Add(Riga);
            WriteToFile();
        }
        public void WriteToFile()
        {
            try
            {
                string[] tempStrings = (string[])StringList.ToArray(typeof(string));
                File.WriteAllLines(Percorso, tempStrings);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nessuna informazione dal salvare");
            }

        }

        public void WriteToFile(ArrayList StringList)
        {
            string[] tempStrings = (string[])StringList.ToArray(typeof(string));
            File.WriteAllLines(Percorso, tempStrings);

        }

        public void WriteToFile(Dictionary<int,string> StringList)
        {
            
                string[] tempStrings = new string[StringList.Count];
                int i = 0;
                foreach (KeyValuePair<int, string> kvp in StringList)
                {

                    tempStrings[i] = kvp.Key.ToString() + "," + kvp.Value.Split(';')[0] + "," + kvp.Value.Split(';')[1];
                    i++;

                }

                File.WriteAllLines(Percorso, tempStrings);
            
        }

    }
}
