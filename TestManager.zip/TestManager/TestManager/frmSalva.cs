﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmSalva : Form
    {


        public string NomeAtleta ="";
        public string NomeSocieta = "";
        private string DefaultName = "";
        private string DefaultSocieta = "";
        public frmSalva(string DefSocieta,string DefName)
        {
            InitializeComponent();
            DefaultName = DefName;
            DefaultSocieta = DefSocieta;
            AcceptButton.DialogResult = DialogResult.OK;
        }

        private void frmSalva_Load(object sender, EventArgs e)
        {
            Archiviazione.FillComboBox(cbSocieta, Archiviazione.GetCartellaAtleti());
            cbSocieta.Text = DefaultSocieta;
            Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
            cbNome.Text = DefaultName;
            btnSave.Focus();
        }

        
        private void btnSave_Click(object sender, EventArgs e)
        {
            NomeAtleta = cbNome.Text;
            NomeSocieta = cbSocieta.Text;
            this.Close();
        }

        private void cbNome_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSave.Focus();
        }

        private void frmSalva_Validated(object sender, EventArgs e)
        {
            btnSave.Focus();
        }

        private void cbSocieta_SelectedIndexChanged(object sender, EventArgs e)
        {
            Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
        

        
    }
}
