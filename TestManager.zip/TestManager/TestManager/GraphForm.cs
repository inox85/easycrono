﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;



namespace TestManager
{
    public partial class GraphForm : Form
    {

        int MaxSample;
        int MinSample;
        int TimeMax;
        int TimeMin;
        int TPercMin = 0;
        int TPercMax = 0;
        int VPercMin = 0;
        int VPercMax = 0;
        int FilterPreset = 3;
        Dictionary<int,string> SamplesDictionary;

        string NomeAtleta;
        string NomeSocieta;

        int NumeroSerie = 0;
       
        public GraphForm(Dictionary<int,string> SamplesDictionary, string NomeSocieta,string NomeAtleta)
        {
            InitializeComponent();
            this.SamplesDictionary = SamplesDictionary;
            this.NomeAtleta = NomeAtleta;
            this.NomeSocieta = NomeSocieta;
            this.Text = "Tempo di reazione - " + NomeAtleta + " " + DateTime.Now.ToShortDateString() + " "+DateTime.Now.ToShortTimeString();
            InitGraph(SamplesDictionary);
            DrawGraph(SamplesDictionary);
            
        }

        public GraphForm()
        {
            InitializeComponent();
            btnSave.Visible = false;
        }

        private void InitGraph(Dictionary<int, string> Campioni)
        {
           
            int NumberOfSamples = Campioni.Count;

            int[] Samples = new int[NumberOfSamples];
            int[] SamplesTime = new int[NumberOfSamples];
            

            int SampleCounter = 0;
            foreach (KeyValuePair<int, string> kvp in Campioni)
            {

                SamplesTime[SampleCounter] = int.Parse(kvp.Value.Split(';')[0]);
                Samples[SampleCounter] = int.Parse(kvp.Value.Split(';')[1]);
                SampleCounter++;
            }
           
        }

        private void DrawGraph(Dictionary<int,string> Campioni)
        {
           
           int NumberOfSamples = Campioni.Count;

            int[] Samples = new int[NumberOfSamples];
            int[] SamplesTime = new int[NumberOfSamples];
            
            try
            {
                MaxSample = int.Parse(Campioni[0].Split(';')[1]);
                MinSample = int.Parse(Campioni[0].Split(';')[1]);
            }
            catch
            {

            }

            int SampleCounter = 0;

            foreach (KeyValuePair<int, string> kvp in Campioni)
            {

                SamplesTime[SampleCounter] = int.Parse(kvp.Value.Split(';')[0]);
                Samples[SampleCounter] = int.Parse(kvp.Value.Split(';')[1]);

                
                if (Samples[SampleCounter] > MaxSample)
                {
                    MaxSample = Samples[SampleCounter];
                    TimeMax = SamplesTime[SampleCounter];
                }

                if (Samples[SampleCounter] < MinSample)
                {
                    MinSample = Samples[SampleCounter];
                    TimeMin = SamplesTime[SampleCounter];
                }

                SampleCounter++;
            }

            Samples = FilterValues(Samples, (int)trbFilter.Value);




            lblRiseTime.Text = CalcolaRiseTime(Campioni).ToString() + " ms";
            lblAccelerazioneMassima.Text = ((double)MaxSample * (3.2226 / 1600)).ToString() + " g";
            try
            {
                lblPendenza.Text = ((double)(MaxSample - MinSample) / (double)CalcolaRiseTime(Campioni)).ToString().Remove(5);
            }
            catch
            {
                lblPendenza.Text = ((double)(MaxSample - MinSample) / (double)CalcolaRiseTime(Campioni)).ToString();
            }
            lblForza50.Text = TPercMin.ToString() + " ms";

            chSample.Series[0].Name = "Spinta"; 
            
                try
                {
                    chSample.Series[0].ChartType = SeriesChartType.Spline;
                    chSample.Series[0].IsValueShownAsLabel = false;
                    chSample.Series[1].ChartType = SeriesChartType.Spline;
                    chSample.Series[2].ChartType = SeriesChartType.Spline;
                    chSample.Series[3].ChartType = SeriesChartType.Spline;
                    chSample.Series[4].ChartType = SeriesChartType.Spline;
                  
                }
                catch
                {

                }
            

            SetSeriesColor();
            try
            {
            chSample.Series[NumeroSerie].SmartLabelStyle.Enabled = false;      
            chSample.Series[NumeroSerie].Points.DataBindXY(SamplesTime, Samples);
            chSample.Series[NumeroSerie].IsValueShownAsLabel = false;
            }
            catch
            {

            }
        }
            private int CalcolaRiseTime(Dictionary<int,string> Samples)
        {
            try
            {

                int FirstSample = int.Parse(Samples[0].Split(';')[1]);

                double Soglia1 = (double)(MaxSample - MinSample) * 0.5;

                foreach (KeyValuePair<int, string> kvp in Samples)
                {

                    if (int.Parse(kvp.Value.Split(';')[1]) >= Soglia1)
                    {
                        TPercMin = int.Parse(kvp.Value.Split(';')[0]);
                        VPercMin = int.Parse(kvp.Value.Split(';')[1]);
                        break;

                    }


                }

                double Soglia2 = (double)(MaxSample - MinSample) * 0.9;

                foreach (KeyValuePair<int, string> kvp in Samples)
                {

                    if (int.Parse(kvp.Value.Split(';')[1]) >= Soglia2)
                    {
                        TPercMax = int.Parse(kvp.Value.Split(';')[0]);
                        VPercMax = int.Parse(kvp.Value.Split(';')[1]);
                        break;
                    }


                }

                return TPercMax - TPercMin;
            }
            catch
            {
                return 0;
            }
            }

            private void rbLinee_CheckedChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void rbPunti_CheckedChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void rbSpline_CheckedChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void tbMinimum_TextChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void tbRange_TextChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void btnSave_Click(object sender, EventArgs e)
            {
                string path = Directory.GetCurrentDirectory();
                
                frmSalva SelezionaNome = new frmSalva(NomeSocieta,NomeAtleta);
                if (SelezionaNome.ShowDialog() == DialogResult.OK)
                {

                    NomeAtleta = SelezionaNome.NomeAtleta;
                    NomeSocieta = SelezionaNome.NomeSocieta;
                    //if (Archiviazione.DirectoryExistAndCreate(Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta))
                    //{
                    //    Archiviazione.DirectoryExistAndCreate(Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta + "\\GraficiReact");
                    //}

                    Archiviazione.VerifiyAndCreateAtletes(NomeSocieta, NomeAtleta);

                    try
                    {
                        //string GrapPath = Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta + "\\"+ Archiviazione.FolderReact +"\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + "_" + DateTime.Now.ToShortTimeString().Replace(":", "_") + ".graph";
                        string GrapPath = Path.Combine(Archiviazione.GetCartellaReactAtleti(NomeSocieta, NomeAtleta), DateTime.Now.ToShortDateString().Replace("/", "_") + "_" + DateTime.Now.ToShortTimeString().Replace(":", "_") + ".graph");

                        TextFile Graph = new TextFile(GrapPath);
                        Graph.WriteToFile(SamplesDictionary);
                        MessageBox.Show("Grafico salvato con successo nella cartella: ...\\" + NomeAtleta + "\\" + Archiviazione.FolderReact);
                        btnSave.Enabled = false;
                    }
                    catch
                    {
                        MessageBox.Show("Errore nel salvataggio del File");
                    }
                }
            }

            private void btnCarica_Click(object sender, EventArgs e)
            {
                
                ofdCarica.InitialDirectory = Directory.GetCurrentDirectory() + "\\Atleti";
                if (ofdCarica.ShowDialog() == DialogResult.OK)
                {
                    TextFile GraphCaricato = new TextFile(ofdCarica.FileName);
                    string[] ListaCampioni = GraphCaricato.Strings;
                    SamplesDictionary = new Dictionary<int,string>();

                    foreach (string s in ListaCampioni)
                    {
                        try
                        {
                            if (s != "")
                            {
                                string[] tempSample = s.Split(',');
                                SamplesDictionary.Add(int.Parse(tempSample[0]), tempSample[1] + ';' + tempSample[2]);
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Rilevati campioni non validi");
                            break;
                        }
                    }
                    InitGraph(SamplesDictionary);
                    DrawGraph(SamplesDictionary);
                NumeroSerie++;
                }

               

            }


            private int[] FilterValues(int[] Samples, int DepthFilter)
            {
                int[] Campioni = Samples;
                
                for (int i = 0; i < Samples.Length; i++)
                {
                    int Sum = 0;

                    for (int c = DepthFilter; c >= 0; c--)
                    {
                        try
                        {
                            Sum += Samples[i - c];
                        }
                        catch
                        {

                        }
                    }
                    if (DepthFilter > 0)
                    {
                        Campioni[i] = Sum / (DepthFilter+1);
                    }
                    else
                    {
                        Campioni = Samples;
                    }
                }
                return Campioni;
            }

   
            private void SetSeriesColor()
            {
                chSample.Series[0].Color = Color.Red;
                chSample.Series[1].Color = Color.Blue;
                chSample.Series[2].Color = Color.Brown;
                chSample.Series[3].Color = Color.DarkGreen;
                chSample.Series[4].Color = Color.DarkMagenta;
            }

            private void trbFilter_ValueChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

            private void cbFiltra_CheckedChanged(object sender, EventArgs e)
            {
                DrawGraph(SamplesDictionary);
            }

           

           
        }
    }

