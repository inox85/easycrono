﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestManager
{
    static class Archiviazione 
    {
        
        public static string FolderAtleti = "Atleti";
        public static string FolderReact = "GraficiReact";
        public static string FolderJump = "JumpTest";
        public static string FolderPrestazioni = "Prestazioni";
        public static string FolderSessioni = "Sessioni";
        public static string FolderGare = "Gara";
        public static string FolderTestScuola = "Test Scuola";


        public static string PathAtleti = Config.GetConfigParams("PathAtleti");

        public static void SalvaInFilePrestazioni(string NomeAtleta, string Misura, string Tempo, string Note,string NomeSocieta)
        {
            TextFile File = new TextFile(Path.Combine(GetCartellaPrestazioniAtleti(NomeSocieta,NomeAtleta),Misura +" Metri.txt") );
            File.AddToFile("["+DateTime.Now.ToShortDateString() + "," + DateTime.Now.ToShortTimeString() + "] Metri: " + Misura + " Tempo: " + Tempo+ " Note: "+ Note);
            File.WriteToFile();   
        }

        public static void SalvaInFileSessione(string NomeAtleta, string Misura, string Tempo, string Note, string NomeSocieta)
        {
            TextFile File = new TextFile(Path.Combine(GetCartellaPrestazioniAtleti(NomeSocieta, NomeAtleta), Misura + " Metri.txt"));
            File.AddToFile("[" + DateTime.Now.ToShortDateString() + "," + DateTime.Now.ToShortTimeString() + "] Societa: " + NomeSocieta + " Atleta: " + NomeAtleta + " Metri: " + Misura + " Tempo: " + Tempo + " Note: " + Note);
            File.WriteToFile();
        }

        public static void SalvaInFileTestScuola(string NomeAtleta, string Misura, string Tempo, string Note, string NomeSocieta)
        {
            string path = Path.Combine(GetCartellaTestScuola(), NomeSocieta + " " + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt");
            TextFile File = new TextFile(path);
            File.AddToFile("[" + DateTime.Now.ToShortDateString() + "," + DateTime.Now.ToShortTimeString() + "] Scuola: " + NomeSocieta + " Atleta: " + NomeAtleta + " Metri: " + Misura + " Tempo: " + Tempo + " Note: " + Note);
            File.WriteToFile();
        }

        public static bool DirectoryExistAndCreate(string Path)
        {
            if (!Directory.Exists(Path))
            {
                try
                {
                    Directory.CreateDirectory(Path);
                    return true;
                }
                catch
                {
                    MessageBox.Show("Errore nella creazione della directory: /r/n" + Path);
                    return false;
                }
            }
            else
            {
                return true;
            }

        }

        public static void FillComboBox(ComboBox cb, string dir)
        {

            try
            {
                string PreviousText = cb.Text;
                cb.Items.Clear();
                string[] Folders = Directory.GetDirectories(dir);
                foreach (string s in Folders)
                {
                    cb.Items.Add(Path.GetFileName(s));
                }
                if (cb.Items.Count > 0)
                {
                    cb.SelectedIndex = 0;
                }
                cb.Text = PreviousText;
            }
            catch
            {
                MessageBox.Show("Errori nel recupero degli atleti, percorso selezionato inesistente");
            }
        }


        public static void VerifiyAndCreateAtletes(string NomeSocieta,string NomeAtleta)
        {

            if (Archiviazione.DirectoryExistAndCreate(GetCartellaAtleta(NomeSocieta,NomeAtleta)))
            {
                Archiviazione.DirectoryExistAndCreate(GetCartellaReactAtleti(NomeSocieta,NomeAtleta));
                Archiviazione.DirectoryExistAndCreate(GetCartellaJumpAtleti(NomeSocieta,NomeAtleta));
                Archiviazione.DirectoryExistAndCreate(GetCartellaPrestazioniAtleti(NomeSocieta,NomeAtleta));
            }
        }

        public static void VerifiyAndCreateGara()
        {
            Archiviazione.DirectoryExistAndCreate(GetCartellaGara());
        }

        public static void VerifiyAndCreateTestScuola()
        {
            Archiviazione.DirectoryExistAndCreate(GetCartellaTestScuola());
        }

        public static void SalvaHeaderInFileJump(string NomeSocieta,string NomeAtleta)
        {
            //TextFile File = new TextFile(Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta + "\\" + FolderJump + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt");
            TextFile File = new TextFile(Path.Combine(GetCartellaJumpAtleti(NomeSocieta,NomeAtleta),DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt"));
            File.AddToFile(" ");
            File.AddToFile("Jump Test [" + DateTime.Now.ToShortDateString() + "," + DateTime.Now.ToShortTimeString() + "]");
            File.AddToFile(" ");
            File.WriteToFile();
        }
        public static void SalvaInFileJump(string NomeSocieta,string NomeAtleta, string NumeroSalto, string TContatto, string TVolo, string Altezza, string JR)
        {
            //TextFile File = new TextFile(Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta + "\\" + FolderJump + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt");
            TextFile File = new TextFile(Path.Combine(GetCartellaJumpAtleti(NomeSocieta,NomeAtleta), DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt"));
            File.AddToFile("[Salto " + NumeroSalto + "]"+ " T.Contatto: " + TContatto +" T.Volo: " + TVolo + " Altezza: " + Altezza + " JR: " + JR);
            File.WriteToFile();
        }

        public static void SalvaHeaderInFileGara()
        {
            //TextFile File = new TextFile(Directory.GetCurrentDirectory() + "\\Atleti\\" + NomeAtleta + "\\" + FolderJump + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt");
            TextFile File = new TextFile(Path.Combine(GetCartellaGara(), DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt"));
            File.AddToFile(" ");
            File.AddToFile("Batteria [" + DateTime.Now.ToShortDateString() + "," + DateTime.Now.ToShortTimeString() + "]");
            File.AddToFile(" ");
            File.WriteToFile();
        }



        public static void SalvaInFileGara(Dictionary<string,string> Arrivi)
        {
            TextFile File = new TextFile(Path.Combine(GetCartellaGara(), DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt"));
            int CountArrivi = 1;
            foreach (KeyValuePair<string, string> kvp in Arrivi)
            {
                File.AddToFile(CountArrivi + " - " + kvp.Key +" -> "+ kvp.Value);
                CountArrivi++;
            }
            //File.AddToFile("[Salto " + NumeroSalto + "]" + " T.Contatto: " + TContatto + " T. Volo: " + TVolo + " Altezza: " + Altezza + " JR: " + JR);
            File.WriteToFile();
        }

        public static string GetCartellaAtleti()
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti);
        }


        public static void getParametriAtleta(string NomeSocieta, string NomeAtleta)
        {
            string filePath = Path.Combine(GetCartellaAtleta(NomeSocieta, NomeAtleta), NomeAtleta + ".txt");

            if (File.Exists(filePath))
            { 

                TextFile file = new TextFile(filePath);

            }
            else
            {
                File.Create(filePath);
            }

        }

        public static string GetCartellaAtleta(string NomeSocieta,string NomeAtleta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti,NomeSocieta,NomeAtleta);
        }

        public static string GetCartellaAtletiSocieta(string NomeSocieta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti, NomeSocieta);
        }

        public static string GetCartellaGara()
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderGare);
        }

        public static string GetCartellaSocieta(string NomeSocieta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti, NomeSocieta);
        }
        public static string GetCartellaSessioniSocieta(string NomeSocieta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti, NomeSocieta,FolderSessioni);
        }
        public static string GetCartellaJumpAtleti(string NomeSocieta, string NomeAtleta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti,NomeSocieta,NomeAtleta,FolderJump);
        }

        public static string GetCartellaReactAtleti(string NomeSocieta, string NomeAtleta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti, NomeSocieta, NomeAtleta, FolderReact);
        }

        public static string GetCartellaPrestazioniAtleti(string NomeSocieta, string NomeAtleta)
        {
            return Path.Combine(Directory.GetCurrentDirectory(), FolderAtleti, NomeSocieta,NomeAtleta, FolderPrestazioni);
        }
        
        public static string GetCartellaTestScuola()
        {
            return Path.Combine(Directory.GetCurrentDirectory(),FolderTestScuola);
        }

    } 
}
