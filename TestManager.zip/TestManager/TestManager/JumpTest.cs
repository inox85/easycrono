﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestManager
{
    class JumpTest
    {
        ArrayList TContatto = new ArrayList();
        ArrayList TVolo = new ArrayList();
        ArrayList TempiContatto = new ArrayList();
        ArrayList TempiVolo = new ArrayList();
        //FrmMain frm = new FrmMain();
        int index = 1;
        public int Counter = 0;
    

     

    }
}
