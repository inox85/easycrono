﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;

namespace TestManager
{
    public static class dbServer
    {
        public static SQLiteConnection m_dbConnection;

        //public static dbServer()
        //{
        //    //SQLiteConnection.CreateFile("MyDatabase.sqlite");

        //    // SQLiteConnection m_dbConnection = new SQLiteConnection("Data Source=MyDatabase.sqlite;Version=3;");
        //    
        //    m_dbConnection.Open();

        //    //string sql = "CREATE TABLE highscores (name varchar(20), score int)";
        //    string sql = "INSERT INTO Atleti (NomeAtleta, AnnoAtleta,Societa,Disciplina) values ('Davide',1985,'Prosport','Velocità')";
        //    SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
        //    command.ExecuteNonQuery();



        //    //command = new SQLiteCommand(sql, m_dbConnection);
        //    //command.ExecuteNonQuery();

        //    m_dbConnection.Close();
        //}

        public static void setDbConnection(string dbPath)
        {
            m_dbConnection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;");
            
            //command = new SQLiteCommand(sql, m_dbConnection);
            //command.ExecuteNonQuery();

           
        }


        public static void insertAtleta(string nome, string cognome, int anno,string societa ,string disciplina)
        {
            m_dbConnection.Open();
            //string sql = "CREATE TABLE highscores (name varchar(20), score int)";
            string sql = "INSERT INTO Atleti (Nome, Cognome, Anno,Societa,Disciplina) values ('" + nome + "', '" + cognome + "', " + anno + " ,'" + societa + "','" + disciplina + "')";
            SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
            command.ExecuteNonQuery();
            m_dbConnection.Close();

        }


    }
}
