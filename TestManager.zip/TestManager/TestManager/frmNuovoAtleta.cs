﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmNuovoAtleta : Form
    {
        public frmNuovoAtleta()
        {
            InitializeComponent();
        }

        private void btnInserisci_Click(object sender, EventArgs e)
        {
            try
            {
                dbServer.insertAtleta(tbNome.Text, tbCognome.Text, int.Parse(tbAnno.Text), tbSocieta.Text, tbDisciplina.Text);
            }
            catch
            {
                MessageBox.Show("Errore nell'inserimento nel database");
            }
        }
    }
}
