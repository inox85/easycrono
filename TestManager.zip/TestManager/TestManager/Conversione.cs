﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestManager
{
   static class Conversione
    {

        public static string MillisToTime(long StartMillis, long StopMillis){

            long Millis = StopMillis - StartMillis;

            long Minuti = Millis / 60000;
            long Secondi = (Millis % 60000) / 1000;
            long Millisecondi = Millis % 1000;
            return TimeFormat(Minuti.ToString(), 2) + ":" + TimeFormat(Secondi.ToString(), 2) + ":" + TimeFormat(Millisecondi.ToString(), 3);
            

        }

        public static string MillisToTime(long Millis)
        {


            long Minuti = Millis / 60000;
            long Secondi = (Millis % 60000) / 1000;
            long Millisecondi = Millis % 1000;
            return TimeFormat(Minuti.ToString(), 2) + ":" + TimeFormat(Secondi.ToString(), 2) + ":" + TimeFormat(Millisecondi.ToString(), 3);


        }

        private static string TimeFormat(string TimeString, int Lenght)
        {
            while (TimeString.Length < Lenght)
            {
                TimeString = "0" + TimeString;
            }
            return TimeString;

        }


        public static int MillisFromTime(string Time)
        {
            int TotalMillis = 0;

            try
            {
                int MillisMin = int.Parse(Time.Split(':')[0]) * 60000;
                int MillisSec = int.Parse(Time.Split(':')[1]) * 1000;
                int Millis = int.Parse(Time.Split(':')[2]);
                TotalMillis = MillisMin + MillisSec + Millis;

            }
            catch
            {
                MessageBox.Show("Impossibile convertire la stringa " + Time + " in un tempo." );
                TotalMillis = 0;
            }

            return TotalMillis;
            
        }

        public static bool TempoMigliore(string Time1, string Time2)
        {
            if (MillisFromTime(Time1) < MillisFromTime(Time2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
