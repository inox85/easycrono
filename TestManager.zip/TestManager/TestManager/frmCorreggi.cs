﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestManager
{
    public partial class frmCorreggi : Form
    {

        public string NomeAtleta = "";
        public string NomeSocieta = "";
        public string Misura = "";
        private string DefaultName = "";
        private string DefaultSocieta = "";
        private string DefaultMisura = "";
        public frmCorreggi(string DefSocieta, string DefName, string DefMisura)
        {
            InitializeComponent();
            DefaultName = DefName;
            DefaultSocieta = DefSocieta;
            DefaultMisura = DefMisura;
            this.AcceptButton.DialogResult = DialogResult.OK;
        }

        private void frmCorreggi_Load(object sender, EventArgs e)
        {
            Archiviazione.FillComboBox(cbSocieta, Archiviazione.GetCartellaAtleti());
            cbSocieta.Text = DefaultSocieta;
            Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
            cbNome.Text = DefaultName;
            btnCorreggi.Focus();
            tbMisura.Text = DefaultMisura;
        }

        private void btnCorreggi_Click(object sender, EventArgs e)
        {
            NomeAtleta = cbNome.Text;
            NomeSocieta = cbSocieta.Text;
            Misura = tbMisura.Text;
            this.Close();
        }
        
        

    }
}
