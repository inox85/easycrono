﻿namespace TestManager
{
    partial class GraphForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series16 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series17 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series18 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series19 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series20 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chSample = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label2 = new System.Windows.Forms.Label();
            this.lblForza50 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCarica = new System.Windows.Forms.Button();
            this.ofdCarica = new System.Windows.Forms.OpenFileDialog();
            this.trbFilter = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.lblAccelerazioneMassima = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRiseTime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPendenza = new System.Windows.Forms.Label();
            this.Pendenza = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chSample)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // chSample
            // 
            this.chSample.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea4.CursorX.IsUserEnabled = true;
            chartArea4.CursorX.IsUserSelectionEnabled = true;
            chartArea4.CursorY.IsUserEnabled = true;
            chartArea4.CursorY.IsUserSelectionEnabled = true;
            chartArea4.Name = "ChartArea1";
            this.chSample.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chSample.Legends.Add(legend4);
            this.chSample.Location = new System.Drawing.Point(-53, -6);
            this.chSample.Name = "chSample";
            series16.ChartArea = "ChartArea1";
            series16.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series16.Legend = "Legend1";
            series16.Name = "Series0";
            series17.ChartArea = "ChartArea1";
            series17.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series17.Legend = "Legend1";
            series17.Name = "Series1";
            series18.ChartArea = "ChartArea1";
            series18.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series18.Legend = "Legend1";
            series18.Name = "Series3";
            series19.ChartArea = "ChartArea1";
            series19.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series19.Legend = "Legend1";
            series19.Name = "Series4";
            series20.ChartArea = "ChartArea1";
            series20.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series20.Legend = "Legend1";
            series20.Name = "Series5";
            this.chSample.Series.Add(series16);
            this.chSample.Series.Add(series17);
            this.chSample.Series.Add(series18);
            this.chSample.Series.Add(series19);
            this.chSample.Series.Add(series20);
            this.chSample.Size = new System.Drawing.Size(1400, 597);
            this.chSample.TabIndex = 0;
            this.chSample.Text = "chart1";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(739, 565);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "Tempo di reazione:";
            // 
            // lblForza50
            // 
            this.lblForza50.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblForza50.AutoSize = true;
            this.lblForza50.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblForza50.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForza50.Location = new System.Drawing.Point(919, 565);
            this.lblForza50.Name = "lblForza50";
            this.lblForza50.Size = new System.Drawing.Size(28, 24);
            this.lblForza50.TabIndex = 8;
            this.lblForza50.Text = "---";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(995, 569);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Salva Grafico";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCarica
            // 
            this.btnCarica.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCarica.Location = new System.Drawing.Point(1076, 568);
            this.btnCarica.Name = "btnCarica";
            this.btnCarica.Size = new System.Drawing.Size(102, 23);
            this.btnCarica.TabIndex = 19;
            this.btnCarica.Text = "Carica/Confronta";
            this.btnCarica.UseVisualStyleBackColor = true;
            this.btnCarica.Click += new System.EventHandler(this.btnCarica_Click);
            // 
            // ofdCarica
            // 
            this.ofdCarica.FileName = "openFileDialog1";
            // 
            // trbFilter
            // 
            this.trbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.trbFilter.Location = new System.Drawing.Point(85, 571);
            this.trbFilter.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.trbFilter.Name = "trbFilter";
            this.trbFilter.Size = new System.Drawing.Size(41, 20);
            this.trbFilter.TabIndex = 20;
            this.trbFilter.Visible = false;
            this.trbFilter.ValueChanged += new System.EventHandler(this.trbFilter_ValueChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(12, 573);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Filtra Disturbi";
            this.label6.Visible = false;
            // 
            // lblAccelerazioneMassima
            // 
            this.lblAccelerazioneMassima.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAccelerazioneMassima.AutoSize = true;
            this.lblAccelerazioneMassima.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAccelerazioneMassima.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccelerazioneMassima.Location = new System.Drawing.Point(1027, 9);
            this.lblAccelerazioneMassima.Name = "lblAccelerazioneMassima";
            this.lblAccelerazioneMassima.Size = new System.Drawing.Size(28, 24);
            this.lblAccelerazioneMassima.TabIndex = 2;
            this.lblAccelerazioneMassima.Text = "---";
            this.lblAccelerazioneMassima.Visible = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(806, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(215, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Accelerazione Massima:";
            this.label3.Visible = false;
            // 
            // lblRiseTime
            // 
            this.lblRiseTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRiseTime.AutoSize = true;
            this.lblRiseTime.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblRiseTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRiseTime.Location = new System.Drawing.Point(721, 9);
            this.lblRiseTime.Name = "lblRiseTime";
            this.lblRiseTime.Size = new System.Drawing.Size(28, 24);
            this.lblRiseTime.TabIndex = 4;
            this.lblRiseTime.Text = "---";
            this.lblRiseTime.Visible = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(615, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Rise Time:";
            this.label1.Visible = false;
            // 
            // lblPendenza
            // 
            this.lblPendenza.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPendenza.AutoSize = true;
            this.lblPendenza.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPendenza.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPendenza.Location = new System.Drawing.Point(538, 9);
            this.lblPendenza.Name = "lblPendenza";
            this.lblPendenza.Size = new System.Drawing.Size(28, 24);
            this.lblPendenza.TabIndex = 6;
            this.lblPendenza.Text = "---";
            this.lblPendenza.Visible = false;
            // 
            // Pendenza
            // 
            this.Pendenza.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pendenza.AutoSize = true;
            this.Pendenza.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Pendenza.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pendenza.Location = new System.Drawing.Point(345, 9);
            this.Pendenza.Name = "Pendenza";
            this.Pendenza.Size = new System.Drawing.Size(174, 24);
            this.Pendenza.TabIndex = 7;
            this.Pendenza.Text = "Pendenza(10-90%):";
            this.Pendenza.Visible = false;
            // 
            // GraphForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 601);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.trbFilter);
            this.Controls.Add(this.btnCarica);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblForza50);
            this.Controls.Add(this.Pendenza);
            this.Controls.Add(this.lblPendenza);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRiseTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblAccelerazioneMassima);
            this.Controls.Add(this.chSample);
            this.Name = "GraphForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tempo di reazione";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.chSample)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbFilter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chSample;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblForza50;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCarica;
        private System.Windows.Forms.OpenFileDialog ofdCarica;
        private System.Windows.Forms.NumericUpDown trbFilter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblAccelerazioneMassima;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRiseTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPendenza;
        private System.Windows.Forms.Label Pendenza;
    }
}