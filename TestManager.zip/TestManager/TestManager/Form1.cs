﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Threading;
using System.Collections;
using System.Diagnostics;
using System.Timers;
using System.Data.SQLite;
using System.Drawing.Printing;

//TODO
//
//
//
//
//
//
//
//

namespace TestManager
{
    public partial class FrmMain : Form
    {
        public delegate void ReceiveDelegate(string StringaRicevuta);
        public ReceiveDelegate DelegatoRicezione;

        string Header;
        string Body;
        string offSett = "0";
        string PrestTemp;
        bool StateStart = false;
        int StartTime;
        int StopTime;
        List<string> Nomi = new List<string>();
        int VisuMillis = 0;
        int ContatoreJump = 0;
        int ContatoreTJump = 0;
        int oldStoptime = 0;
        Dictionary<int,string> Stacchi = new Dictionary<int,string>();
        Dictionary<int,string> Atterraggi = new Dictionary<int,string>();
        Dictionary<int, string> Contatti = new Dictionary<int, string>();
        Dictionary<int, string> Voli = new Dictionary<int, string>();
        Dictionary<int,string> ReactSamples = new Dictionary<int, string>();
        JumpTest JTest = new JumpTest();
        bool PedanaOK = false;
        bool firstBeforeStart = false;
        bool firstStart = true;
        bool onStart = false;


        double maxBatt = 860;
        double minBatt = 650;

        int CifreJump = 6;

        int CountBatteria = 0;
        int CountArrivi = 0;
        Dictionary<string,string> BatteriaAtleti;

        public FrmMain()
        {

            InitializeComponent();
            this.DelegatoRicezione = new ReceiveDelegate(ReceiveMethod);
            //UpdateNames();
            
        }

        

        public void ReceiveMethod(string StringaRicevuta)
        {
            
            tmrTimeOut.Enabled = false;

            lblDebug.Text = StringaRicevuta;
         
            Header = StringaRicevuta.Split(';')[0];
            Body = StringaRicevuta.Split(';')[1];

            if(StringaRicevuta.Split(';').Length > 2)
            {
                offSett = StringaRicevuta.Split(';')[2];
            }

            switch (Header)
            {

                case "b":

                    lblBatt.Text = calculateBattery(double.Parse(Body)).ToString() + "%";
                    break;

                case "v":


                case "k":

                        Contatto(Body);
                        lblJumpTest.Text = "Test in corso, premere Inizia Jump Test per iniziare un nuovo Test";
                    break;

                case "j":

                        Volo(Body);
                        lblJumpTest.Text = "Test in corso, premere Inizia Jump Test per iniziare un nuovo Test";
                    break;
  
                case "c":
                    okConnection();
                    //cbPorta.BackColor = Color.Green;
                    //cbPorta.Enabled = false;
                    //btnConnect.Visible = false;
                    //cbPorts.Visible = false;
                    break;

                case "s":
                    if (tracciatoAdAnelloToolStripMenuItem.Checked)
                    {
                        if (firstStart)
                        {
                            startRoutine(0);
                            firstStart = false;
                            setResetButtonArmed();
                        }
                        else
                        {
                            stopRoutine();
                        }
                    }
                    else
                    {
                        startRoutine(0);
                    }
                 
                    break;
                case "z":

                    if (tracciatoAdAnelloToolStripMenuItem.Checked)
                    {
                        if (firstStart)
                        {
                            startRoutine(int.Parse(offSett));
                            firstStart = false;
                            setResetButtonArmed();
                        }
                        else
                        {
                            stopRoutine();
                        }
                    }
                    else if (rbStart.Checked)
                    {

                        startRoutine(int.Parse(offSett));

                    }
                    else
                    {
                        stopRoutine();
                    }

                    break;
                case "r":

                       //lbJumpTest.Items.Clear();
                       dgvJumpTest.Rows.Clear();
                       ResetJumpDone();
                   break;
                    
                case "p":

                   if (tracciatoAdAnelloToolStripMenuItem.Checked)
                   {

                        if (firstStart)
                        {
                            startRoutine(0);
                            firstStart = false;
                            setResetButtonArmed();
                        }else
                        {
                            stopRoutine();
                        }

                   }
                   else
                   {
                       stopRoutine();
                   }
                   
                break;

                case "i":

                        GraphForm Grafico = new GraphForm(ReactSamples,cbSocieta.Text,cbNome.Text);
                        pbDownload.Value = 0;
                        Grafico.Show();
                        

                break;

                case "t":
                        btnReactTime.BackColor = Color.LightBlue;
                
                break;

                case "u":
                        btnReactTime.BackColor = Color.LightBlue;

                break;

                case "e":
                        btnReactTime.BackColor = Color.LightGreen;
                        ReactSamples = new Dictionary<int, string>();
                        InviaCmd("d");
                break;

                case "d":
                        AggiungiSample(Body);
                        pbDownload.Value = int.Parse(Body.Split('-')[0]);
                        InviaCmd("d");
                break;

                case "a":
                        PedanaOK = true;
                        lblJumpTest.Text = "Pronto a Saltare";
                        ResetJumpResetEnable();
                break;
                //lbJumpTest.Items.Add("Pronto a Saltare");    
              
                
            }
            tmrTimeOut.Enabled = true;
        }

        private void startRoutine(int initTime) 
        {
            if (!StateStart)
            {
                SetVariabiliStart();
                onStart = true;
                firstBeforeStart = true;
                //tmrMain.Enabled = true;
                StartTime = int.Parse(Body);
                StartVisu(initTime);
                setResetButton();
            }

        }
        
        private int calculateBattery(double battLevel)
        {
            return (int)(((battLevel-minBatt) / (maxBatt - minBatt))*100);
        }

        private void setResetButton()
        {
            btnReset.BackColor = Color.OrangeRed;
        }

        private void resetResetButton()
        {
            btnReset.BackColor = Color.Azure;
        }

        private void stopRoutine()
        {
            if ((StateStart) && (!cbBatteria.Checked))
            {
                SetVariabiliStop();
                oldStoptime = StopTime;
                StopTime = int.Parse(Body);
                StopVisu();
                lblTime.Text = Conversione.MillisToTime(StartTime, StopTime);
                PrestTemp = Conversione.MillisToTime(StartTime, StopTime);

                if (tabTest.SelectedTab == tabSpeedTest)
                {
                    if (visualizzaIntertempiToolStripMenuItem.Checked && !firstBeforeStart)
                    {
                        PrestTemp += " +" + Conversione.MillisToTime(oldStoptime, StopTime);
                    }

                    InserisciPrestazione(dgvPrestazioni, cbNome.Text, tbMisura.Text, PrestTemp, "", cbSocieta.Text);
                }
                else if (tabTest.SelectedTab == tabTestScuola)
                {
                    InserisciPrestazione(dgvTestScuola, tbNome.Text, tbMisura.Text, PrestTemp, "", cbSocieta.Text);
                    ScrollDgv(dgvTestScuola);
                }
            }
            else if (cbBatteria.Checked)
            {
                SetVariabiliStop();
                StopTime = int.Parse(Body);
                StopVisu();
                lblTime.Text = Conversione.MillisToTime(StartTime, StopTime);
                PrestTemp = Conversione.MillisToTime(StartTime, StopTime);
                InserisciPrestazione(dgvPrestazioni, "Atleta " + CountArrivi, tbMisura.Text, PrestTemp, "", "");
                CountArrivi++;
                if (CountArrivi >= CountBatteria)
                {
                    AssegnaArriviEReset();
                }
            }
            firstBeforeStart = false;
        }

        private void AssegnaArriviEReset()
        {
            btnAssegna_Click(null, null);
            CountArrivi = 0;
        }
        private void ResetJumpDone()
        {
            btnRstJump.Enabled = false;
        }
        private void ResetJumpResetEnable()
        {
            btnRstJump.Enabled = true;
        }

        private void SetVariabiliStart()
        {
            StateStart = true;     
        }

        private void SetVariabiliStop()
        {
            //StateStart = false; 
            
        }
        private void AggiungiSample(string Sample)
        {
            if (int.Parse(Sample.Split('-')[0]) < 25)
            {
                ReactSamples.Add(int.Parse(Sample.Split('-')[0]), Sample.Split('-')[1] + ";0");
            }
            else
            {
                ReactSamples.Add(int.Parse(Sample.Split('-')[0]), Sample.Split('-')[1] + ";" + Sample.Split('-')[2]);
            }
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
          
                InviaCmd("s");
            
        }

        private void StartVisu(int initTime)
        {
            VisuMillis = initTime;
            tmrMain.Enabled = true;
        }

        private void StopVisu()
        {
            tmrMain.Enabled = false;
            double RatioTime =  (double)(StopTime - StartTime)/(double)VisuMillis;
            
        }

        private void InviaCmd(string Cmd)
        {

            tmrTimeOut.Enabled = true;

            try
            {
                if (!SerialeCronometro.IsOpen)
                {
                    SerialeCronometro.Open();
                    SerialeCronometro.DtrEnable = true;
                    SerialeCronometro.RtsEnable = true;
                }

                SerialeCronometro.WriteLine(Cmd);

            }
            catch (Exception)
            {

               

            }
        }

        private void SerialeCronometro_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadLine();
            try
            {
                Invoke(DelegatoRicezione, new object[] { indata });
            }catch
            {

            }
        }

        private void tmrMain_Tick(object sender, EventArgs e)
        {
            lblTime.Text = Conversione.MillisToTime(VisuMillis);
            VisuMillis += 100;
        }

        private void bntStop_Click(object sender, EventArgs e)
        { 
                InviaCmd("p");
            
        }

        private void cbPorta_Click(object sender, EventArgs e)
        {
            //cbPorta.Items.Clear();

            //foreach (string PortName in SerialPort.GetPortNames())
            //{

            //    cbPorta.Items.Add(PortName);

            //}
        }

        private void InserisciPrestazione(DataGridView dgv, string Nome, string Misura, string Tempo, string Note, string Societa) {

            //lbPrestazioni.Items.Add(Nome + "-" + Misura + " Metri-" + Tempo);
            dgv.Rows.Add(Nome, Misura, Tempo, Note,Societa);
            ScrollDgv(dgv);

        }

        private void InserisciPrestazione(List<string> Cell, string Misura, string Tempo, string Note, string Societa)
        {

            //lbPrestazioni.Items.Add(Nome + "-" + Misura + " Metri-" + Tempo);
            dgvPrestazioni.Rows.Add(Cell, Misura, Tempo, Note, Societa);
            ScrollDgv(dgvPrestazioni);

        }

        private void btnAggiungi_Click(object sender, EventArgs e)
        {
           
                if (cbSocieta.Text != "")
                {
                    Archiviazione.VerifiyAndCreateAtletes(cbSocieta.Text, tbNome.Text);
                    Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
                    tbNome.Text = "";
                }
                else
                {

                    MessageBox.Show("Selezionare una società, se non è presente crearne una. Tools -> Crea Cartella Società");

                }
            

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            //chkLicense();


            dbServer.setDbConnection(Path.Combine(Directory.GetCurrentDirectory(), "dbAtleti"));


            cbPorts.Visible = false;
            cbPorts.Items.Clear();

            foreach (string PortName in SerialPort.GetPortNames())
            {
                cbPorts.Items.Add(PortName);
            }
            tryConnect();

            //cbPorts.Text = SerialeCronometro.PortName;

            //SelectValueCb(cbPorta);
            btnReactTime.BackColor = Color.LightGreen;
            UpdateAllComboBox();

            tmrTimeOut.Enabled = true;

            tabTest.TabPages.Remove(tabTestScuola);

        }



        private void chkLicense()
        {
            DateTime scadenza = new DateTime(2016, 12, 12);
            if (DateTime.Now > scadenza)
            {
                MessageBox.Show("Licenza Scaduta,l'applicazione verrà chiusa");
                Application.Exit();
            }
        }

        private void tryConnect()
        {
            
            try
            {
                string[] portNames = SerialPort.GetPortNames();

                if (portNames.Length > 0)
                {
                    foreach (string s in portNames)
                    {
                        SerialeCronometro.Close();
                        SerialeCronometro.PortName = s;
                        InviaCmd("c");
                        Thread.Sleep(100);
                        //cbPorta.BackColor = Color.Red;
                    }
                }
                else
                {
                    MessageBox.Show("Nessuna risposta dal dispositivio esterno. Verificare la connessione.");
                }
            }
            catch
            {
                MessageBox.Show("Nessuna risposta dal dispositivio esterno. Verificare la connessione.");
            }
        }

        private void UpdateAllComboBox()
        {
            Archiviazione.FillComboBox(cbSocieta, Archiviazione.GetCartellaAtleti());
            SelectValueCb(cbSocieta);
            Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
            SelectValueCb(cbNome);
        }

        private void SelectValueCb(ComboBox cb)
        {
            if (cb.Items.Count > 0)
            {
                cb.SelectedIndex = 0;
            }
        }

     

        private void btnEsporta_Click(object sender, EventArgs e)
        {

            if (Archiviazione.DirectoryExistAndCreate(Directory.GetCurrentDirectory() + "\\Atleti\\TestSessione"))
            {
                //string PathFile = Directory.GetCurrentDirectory() + "\\Atleti\\TestSessione\\Test_" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt";
                string PathFile = Path.Combine(Archiviazione.GetCartellaSessioniSocieta(cbSocieta.Text),DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt");

                string[] ListBoxLines = new string[dgvPrestazioni.Rows.Count];

                foreach (DataGridViewRow row in dgvPrestazioni.Rows)
                {
                    try
                    {
                        Archiviazione.SalvaInFileSessione(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), row.Cells[4].Value.ToString());
                    }
                    catch
                    {

                    }

                }

            }
            


        }

        private void btnRstJump_Click(object sender, EventArgs e)
        {
            PedanaOK = false;
            Voli = new Dictionary<int, string>();
            Contatti = new Dictionary<int, string>();
            Stacchi = new Dictionary<int, string>();
            Atterraggi = new Dictionary<int, string>();
            ResetLabelJump();
            InviaCmd("r");
            ContatoreTJump = 0;
            ContatoreJump = 0;
        }

        private void ResetLabelJump()
        {
            lblJumpTest.Text = "Salire sulla pedana per iniziare il Jump Test";
        }

        private void InVolo()
        {
            lblJumpTest.Text = "In Volo";
        }

        private void ATerra()
        {
            lblJumpTest.Text = "A Terra";
        }

        private void CalcolaJump()
        {
            Voli.Add(ContatoreTJump,(int.Parse(Atterraggi[ContatoreTJump])-int.Parse(Stacchi[ContatoreTJump])).ToString());
            if (ContatoreTJump > 0)
            {
                Contatti.Add(ContatoreTJump, (int.Parse(Stacchi[ContatoreTJump]) - int.Parse(Atterraggi[ContatoreTJump - 1])).ToString());
            }
            if (ContatoreTJump > 0)
            {

                //lbJumpTest.Items.Add(ContatoreTJump + " - Contatto: " + GetContatto(Contatti[ContatoreTJump]) + " -> Volo: " + GetVolo(Voli[ContatoreTJump]) + " | Altezza: " + Altezza(int.Parse(Voli[ContatoreTJump])) + " | JR: " + GetJR(Contatti[ContatoreTJump], Voli[ContatoreTJump]));

                dgvJumpTest.Rows.Add(ContatoreJump, GetContatto(Contatti[ContatoreTJump]), GetVolo(Voli[ContatoreTJump]), Altezza(int.Parse(Voli[ContatoreTJump])), GetJR(Contatti[ContatoreTJump], Voli[ContatoreTJump]));
                ScrollDgv(dgvJumpTest);
            }
            else
            {
                //lbJumpTest.Items.Add(ContatoreTJump + " - Volo: " + GetVolo(Voli[ContatoreTJump]));

                dgvJumpTest.Rows.Add(ContatoreJump,"", GetVolo(Voli[ContatoreTJump]), Altezza(int.Parse(Voli[ContatoreTJump])), "");
                ScrollDgv(dgvJumpTest);
            }
            ContatoreTJump++;
            
        }

        private string GetJR(string p1, string p2)
        {
            string jr = (double.Parse(Voli[ContatoreTJump]) / double.Parse(Contatti[ContatoreTJump])).ToString();

            if (jr.Length > CifreJump)
            {
                return jr.Remove(6);
            }
            return jr;

        }

        private string GetContatto(string p)
        {
            if (p.Length > CifreJump)
            {
                return p.Remove(6);
            }
            return p;
        }

        private string GetVolo(string p)
        {
            if (p.Length > CifreJump)
            {
                return p.Remove(6);
            }
            return p;
        }


        private void ScrollDgv(DataGridView dgv)
        {
            dgv.FirstDisplayedScrollingRowIndex = dgv.RowCount - 1;
        }

       private void Contatto(string Ta)
       {
           if (PedanaOK)
           {  
               Atterraggi.Add(ContatoreJump,Ta);
               ContatoreJump++;
               CalcolaJump();
           }
           else
           {
               lblJumpTest.Text = "Attendere sulla pedana";
           }

       }


        private void Volo(string Ts)
        {
            if (PedanaOK)
            {
                Stacchi.Add(ContatoreJump, Ts);   
            }
           
        }

        private string Altezza(int TVolo)
        {

            double TempoVolo = (double)TVolo / 1000;
           
            double H = Math.Round((((0.5)*(9.81)*Math.Pow(TempoVolo/2,2))),4);

            string h = H.ToString();

            if (h.Length > CifreJump)
            {
                //return h.Remove(6);
                return h;
            }
            return h;

        }

        private void btnReactTime_Click(object sender, EventArgs e)
        {
           
            if (cbReactAndSpeed.Checked)
            {
                InviaCmd("u");
            }
            else
            {
                InviaCmd("t");
            }
        }

        

        private void btnArchivia_Click(object sender, EventArgs e)
        {
            if (cbBatteria.Checked)
            {
                Archiviazione.VerifiyAndCreateGara();
                Dictionary<string, string> Arrivi = new Dictionary<string, string>();

                foreach (DataGridViewRow row in dgvPrestazioni.Rows)
                {
                    try
                    {
                        if (row.Index == dgvPrestazioni.Rows.Count - 1)
                        {
                            dgvPrestazioni.Rows.Clear();
                        }
                        Arrivi.Add(row.Cells[0].Value.ToString(), row.Cells[2].Value.ToString());
                        cbBatteria.Checked = false;
                        cbBatteria.Text = "Modo Batteria";
                    }
                    catch
                    {
                        
                    }
                }

                    Archiviazione.SalvaHeaderInFileGara();
                    Archiviazione.SalvaInFileGara(Arrivi);
                    //cbBatteria.Checked = false;
            }
            else
            {
                foreach (DataGridViewRow row in dgvPrestazioni.Rows)
                {
                    try
                    {

                        if (row.Index == dgvPrestazioni.Rows.Count - 1)
                        {
                            dgvPrestazioni.Rows.Clear();
                        }
                        Archiviazione.VerifiyAndCreateAtletes(row.Cells[4].Value.ToString(), row.Cells[0].Value.ToString());
                        Archiviazione.SalvaInFilePrestazioni(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), row.Cells[4].Value.ToString());

                    }
                    catch
                    {

                    }

                }
            }
        }

        private void apriGraficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GraphForm EmptyGraph = new GraphForm();
            EmptyGraph.ShowDialog();
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            eliminaRiga(dgvPrestazioni);
        }

        private void eliminaRiga(DataGridView dgv) 
        {
            try
            {
                dgv.Rows.Remove(dgvPrestazioni.CurrentRow);
            }
            catch
            {

            }
        }
        private void cbNome_Click(object sender, EventArgs e)
        {
            //UpdateNames();
            Archiviazione.FillComboBox(cbNome,Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
        }

        private void cbSocieta_Click(object sender, EventArgs e)
        {
            Archiviazione.FillComboBox(cbSocieta, Archiviazione.GetCartellaAtleti());
        }

        private void btnStorico_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Archiviazione.GetCartellaPrestazioniAtleti(cbSocieta.Text,cbNome.Text));
            }catch
            {
                MessageBox.Show("Impossibile trovare il file dello Storico");
            }
        }

        private void btnAllega_Click(object sender, EventArgs e)
        {

            DataGridViewRow Row = dgvPrestazioni.CurrentRow;
            try
            {
                ofdAllega.InitialDirectory = Archiviazione.GetCartellaReactAtleti(cbSocieta.Text,cbNome.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Selezionare una riga valida alla quale allegare un nome file");
            }

            if (ofdAllega.ShowDialog() == DialogResult.OK)
            {
                Row.Cells[3].Value = Path.GetFileName(ofdAllega.FileName);
            }
            
        }

        private void btnCartella_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Archiviazione.GetCartellaAtleta(cbSocieta.Text,cbNome.Text));
            }
            catch
            {
                MessageBox.Show("Impossibile trovare la cartella relativa all'atleta");
            }
        }

        private void apriCartellaAtletiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Archiviazione.GetCartellaAtleti());
            }
            catch
            {
                MessageBox.Show("Impossibile trovare la cartella Atleti");
            }
        }

        private void btnSaveJumpTest_Click(object sender, EventArgs e)
        {
            if (dgvJumpTest.Rows.Count > 1)
            {
                string NomeAtleta = cbNome.Text;
                string NomeSocieta = cbSocieta.Text;

                frmSalva SelectName = new frmSalva(cbSocieta.Text,cbNome.Text);
                SelectName.ShowDialog();
                
                NomeAtleta = SelectName.NomeAtleta;
                NomeSocieta = SelectName.NomeSocieta;

                Archiviazione.SalvaHeaderInFileJump(NomeSocieta,NomeAtleta);

                foreach (DataGridViewRow row in dgvJumpTest.Rows)
                {
                    Archiviazione.VerifiyAndCreateAtletes(NomeSocieta,NomeAtleta);

                    try
                    {
                        if (row.Index == dgvJumpTest.Rows.Count - 1)
                        {
                            dgvJumpTest.Rows.Clear();
                        }
                        Archiviazione.SalvaInFileJump(NomeSocieta,NomeAtleta, row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), row.Cells[4].Value.ToString());

                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Nessuna Informazione dal salvare");
            }
            

        }

     

        private void tmrTimeOut_Tick(object sender, EventArgs e)
        {
            //tmrTimeOut.Enabled = false;
            //cbPorta.Enabled = true;
            //MessageBox.Show("Nessuna risposta dal dispositivio esterno. Verificare la connessione.");
            string[] ports = SerialPort.GetPortNames();
            noConnection();

            //btnConnect.Visible = true;
            cbPorts.Visible = true;
            
        }

        

       
        private void cbSocieta_SelectedIndexChanged(object sender, EventArgs e)
        {
            Archiviazione.FillComboBox(cbNome, Archiviazione.GetCartellaAtletiSocieta(cbSocieta.Text));
        }

        private void creaCartellaSocietàToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAggiungiSocieta AggiungiSocieta = new frmAggiungiSocieta();
            AggiungiSocieta.ShowDialog();
        }

        private void btnCambiaAtleta_Click(object sender, EventArgs e)
        {
            try
            {
                frmCorreggi CorreggiAtleta = new frmCorreggi(dgvPrestazioni.CurrentRow.Cells[4].Value.ToString(), dgvPrestazioni.CurrentRow.Cells[0].Value.ToString(), dgvPrestazioni.CurrentRow.Cells[1].Value.ToString());
                if (CorreggiAtleta.ShowDialog() == DialogResult.OK)
                {
                    dgvPrestazioni.CurrentRow.Cells[0].Value = CorreggiAtleta.NomeAtleta;
                    dgvPrestazioni.CurrentRow.Cells[1].Value = CorreggiAtleta.Misura;
                    dgvPrestazioni.CurrentRow.Cells[4].Value = CorreggiAtleta.NomeSocieta;
                }
            }
            catch
            {

            }
        }

        private void cbBatteria_CheckedChanged(object sender, EventArgs e)
        {
            if (cbBatteria.Checked && MessageBox.Show("L'attivazione del Modo Gara eliminerà gli arrivi attualmente presenti. Proseguire?", "Conferma", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                //InviaCmd("p");
                dgvPrestazioni.Rows.Clear();
                frmBatteria InserisciBatteria = new frmBatteria();
                btnReset.PerformClick();
                btnArchivia.Text = "Archivia Batteria";
               
                    InserisciBatteria.ShowDialog();
                    if (InserisciBatteria.Batteria.Count > 0)
                    {
                        CountBatteria = InserisciBatteria.Batteria.Count;
                        
                        BatteriaAtleti = InserisciBatteria.Batteria;
                        cbBatteria.Text = "Atleti Batteria: " + InserisciBatteria.Batteria.Count.ToString();
                        
                   }
            }
            else if (!cbBatteria.Checked)
            {
                
                btnArchivia.Text = "Archivia";
                cbBatteria.Text = "Modo Batteria";
            }


        }


  

        private void btnAssegna_Click(object sender, EventArgs e)
        {
            frmAssegnaArrivo AssegnaArrivi = new frmAssegnaArrivo(dgvPrestazioni, BatteriaAtleti);
            AssegnaArrivi.ShowDialog();
            int CountRow = 0;

            foreach (KeyValuePair<string,string> kvp in AssegnaArrivi.Arrivi)
            {
                dgvPrestazioni[0, CountRow].Value = kvp.Key;
                dgvPrestazioni[3, CountRow].Value = kvp.Value;
                CountRow++;
            }

            //cbBatteria.Checked = false;
        }

        private void apriCartellaGaraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Archiviazione.GetCartellaGara());
            }
            catch
            {
                MessageBox.Show("Impossibile trovare la cartella Gara");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InviaCmd("s");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InviaCmd("p");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            eliminaRiga(dgvTestScuola);
        }

        private void btnArchiviaTestScuola_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvTestScuola.Rows)
            {
                Archiviazione.VerifiyAndCreateTestScuola();
                try
                {
                    if (row.Index == dgvTestScuola.Rows.Count - 1)
                    {
                        dgvTestScuola.Rows.Clear();
                    }
                    Archiviazione.SalvaInFileTestScuola(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), row.Cells[4].Value.ToString());
                }
                catch
                {

                }
            }


            //cbBatteria.Checked = false;
        }

        private void cbInverti_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void tabTest_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabTest.SelectedTab == tabTestScuola) 
            {

                cbSocieta.Visible = false;
                cbNome.Visible = false;
                btnStorico.Visible = false;
                btnCartella.Visible = false;
                label8.Visible = false;
                label3.Visible = false;
                btnAggiungi.Visible = false;
                tbMisura.Visible = true;
                label6.Visible = true;
                label7.Visible = true;


            }else if (tabTest.SelectedTab == tabJumpTest)
            {

                cbSocieta.Visible = true;
                cbNome.Visible = true;
                btnStorico.Visible = true;
                btnCartella.Visible = true;
                label8.Visible = true;
                label3.Visible = true;
                btnAggiungi.Visible = true;
                tbMisura.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
            }
            else if (tabTest.SelectedTab == tabSpeedTest)
            {
                cbSocieta.Visible = true;
                cbNome.Visible = true;
                btnStorico.Visible = true;
                btnCartella.Visible = true;
                label8.Visible = true;
                label3.Visible = true;
                btnAggiungi.Visible = true;
                tbMisura.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
            }


        }

        private void cbInterTempi_CheckedChanged(object sender, EventArgs e)
        {
     
        }

        private void cbStartMultistop_CheckedChanged(object sender, EventArgs e)
        {
            if (tracciatoAdAnelloToolStripMenuItem.Checked)
            {
                firstStart = true;
                //cbInverti.Checked = false;
                //cbInverti.Enabled = false;
               
              
                cbReactAndSpeed.Checked = true;
                cbReactAndSpeed.Enabled = false;
                //cbInterTempi.Checked = true;
                //cbInterTempi.Enabled = false;
            }
            else
            {

                //cbInverti.Enabled = true;
                
               
                cbReactAndSpeed.Checked = false;
                cbReactAndSpeed.Enabled = true;
                //cbInterTempi.Checked = false;
                //cbInterTempi.Enabled = true;
            }
        }

        private void setResetButtonArmed()
        {
            btnReset.BackColor = Color.LightSalmon;
        }

        private void rstResetButton()
        {
            btnReset.BackColor = Color.Azure;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            firstStart = true;
            //onStart = false;
            StateStart = false;
            StartTime = 0;
            lblTime.Text = Conversione.MillisToTime(0);
            rstResetButton();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                    SerialeCronometro.Close();
                    SerialeCronometro.PortName = cbPorts.Text;
                    InviaCmd("c");
                    Thread.Sleep(100);
                    //cbPorta.BackColor = Color.Red;
               
            }
            catch
            {

            }
        }

        private void cbPorts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //SerialeCronometro.Close();
                //SerialeCronometro.PortName = cbPorts.Text;
                //SerialeCronometro.Open();
                //SerialeCronometro.DtrEnable = true;
                //SerialeCronometro.RtsEnable = true;

                openPort(cbPorts.Text);
            }
            catch
            {
                noConnection();
            }
        }

        private void cbPorts_Click(object sender, EventArgs e)
        {
            cbPorts.Items.Clear();

            foreach (string PortName in SerialPort.GetPortNames())
            {
                cbPorts.Items.Add(PortName);
            }
        }

        private void openPort(string portName)
        {
            SerialeCronometro.Close();
            SerialeCronometro.PortName = portName;
            SerialeCronometro.Open();
            SerialeCronometro.DtrEnable = true;
            SerialeCronometro.RtsEnable = true;
        }

        private void btnSchedaAtleta_Click(object sender, EventArgs e)
        {
            Archiviazione.getParametriAtleta(cbSocieta.Text, cbNome.Text);
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sicuro di elminare tutti i risultati?", "Conferma", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                dgvPrestazioni.Rows.Clear();
            }
        }

   
        private void noConnection()
        {
            cbPorts.Visible = true;
            pbConnection.BackColor = Color.Red;
        }

        private void okConnection()
        {
            cbPorts.Visible = false;
            pbConnection.BackColor = Color.Green;
        }

        private void tracciatoAdAnelloToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if(tracciatoAdAnelloToolStripMenuItem.Checked)
            MessageBox.Show("Si sta utilizzando la modalità per tracciati ad anello, con una singola fotocellula che corrispone sia allo START che allo STOP. Solo il primo passaggio dopo il RESET corrisponderà allo START, tutti i consecutivi agli STOP.");
        }

        private void atletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNuovoAtleta nuovoAtleta = new frmNuovoAtleta();
            nuovoAtleta.Show();
        }

        Bitmap bmp;

        private void btnStampa_Click(object sender, EventArgs e)
        {

            int height = dgvPrestazioni.Height;
            int width = dgvPrestazioni.Width;
            int tempWidth = dgvPrestazioni.RowHeadersWidth;
            dgvPrestazioni.Height = dgvPrestazioni.RowCount * dgvPrestazioni.RowTemplate.Height * 2;

            foreach (DataGridViewColumn clm in dgvPrestazioni.Columns)
            {
                tempWidth += clm.Width;
            } 

            bmp = new Bitmap(tempWidth, dgvPrestazioni.Height);

            dgvPrestazioni.Height = height;
            dgvPrestazioni.Width = width;

            dgvPrestazioni.DrawToBitmap(bmp, new Rectangle(0, 0, dgvPrestazioni.Width, dgvPrestazioni.Height));
            //frmBmp viwer = new frmBmp(bmp);
            //viwer.ShowDialog();

            PrintDialog pd = new PrintDialog();
            pd.PrinterSettings = new PrinterSettings();
            if (pd.ShowDialog() == DialogResult.OK)
            {
                
                printDocument.Print();
            }
                // printDocument.OriginAtMargins = false;
                // printDocument.DefaultPageSettings.Landscape = false;

                

        }

        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            double cmToUnits = 100 / 2.54;
            e.Graphics.DrawImage(bmp , 0, 0);
        }

        private void tracciatoAdAnelloToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
