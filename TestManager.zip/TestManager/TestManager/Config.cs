﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestManager
{
    public static class Config
    {
        private static TextFile ConfigFile; 
        public static Dictionary<string, string> ConfigParams = new Dictionary<string, string>();
        public static string GetConfigParams(string Params)
        {
            ConfigFile= new TextFile(Path.Combine(Directory.GetCurrentDirectory(), "Config.txt"));
            try
            {
                foreach (string s in ConfigFile.Strings)
                {
                    ConfigParams.Add(s.Split('=')[0], s.Split('=')[1]);
                }

                return ConfigParams[Params];
            }catch
            {
                return Directory.GetCurrentDirectory();
            }
        }

    }
}
