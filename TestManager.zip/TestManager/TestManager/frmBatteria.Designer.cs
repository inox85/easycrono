﻿namespace TestManager
{
    partial class frmBatteria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAggiungi = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRimuovi = new System.Windows.Forms.Button();
            this.dgvBatteria = new System.Windows.Forms.DataGridView();
            this.clmAtleta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnConferma = new System.Windows.Forms.Button();
            this.btnAnnulla = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNote = new System.Windows.Forms.TextBox();
            this.btnLoadExcel = new System.Windows.Forms.Button();
            this.ofdBatteria = new System.Windows.Forms.OpenFileDialog();
            this.cbBatterie = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatteria)).BeginInit();
            this.SuspendLayout();
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(15, 25);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(185, 20);
            this.tbNome.TabIndex = 0;
            this.tbNome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbNome_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome Atleta";
            // 
            // btnAggiungi
            // 
            this.btnAggiungi.Location = new System.Drawing.Point(301, 51);
            this.btnAggiungi.Name = "btnAggiungi";
            this.btnAggiungi.Size = new System.Drawing.Size(75, 23);
            this.btnAggiungi.TabIndex = 3;
            this.btnAggiungi.Text = "Aggiungi";
            this.btnAggiungi.UseVisualStyleBackColor = true;
            this.btnAggiungi.Click += new System.EventHandler(this.btnAggiungi_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Batteria";
            // 
            // btnRimuovi
            // 
            this.btnRimuovi.Location = new System.Drawing.Point(15, 298);
            this.btnRimuovi.Name = "btnRimuovi";
            this.btnRimuovi.Size = new System.Drawing.Size(75, 23);
            this.btnRimuovi.TabIndex = 5;
            this.btnRimuovi.Text = "Rimuovi";
            this.btnRimuovi.UseVisualStyleBackColor = true;
            this.btnRimuovi.Click += new System.EventHandler(this.btnRimuovi_Click);
            // 
            // dgvBatteria
            // 
            this.dgvBatteria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBatteria.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmAtleta,
            this.Note});
            this.dgvBatteria.Location = new System.Drawing.Point(15, 80);
            this.dgvBatteria.Name = "dgvBatteria";
            this.dgvBatteria.Size = new System.Drawing.Size(492, 212);
            this.dgvBatteria.TabIndex = 6;
            // 
            // clmAtleta
            // 
            this.clmAtleta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmAtleta.HeaderText = "Atleta";
            this.clmAtleta.Name = "clmAtleta";
            this.clmAtleta.Width = 59;
            // 
            // Note
            // 
            this.Note.HeaderText = "Note";
            this.Note.Name = "Note";
            // 
            // btnConferma
            // 
            this.btnConferma.Location = new System.Drawing.Point(432, 298);
            this.btnConferma.Name = "btnConferma";
            this.btnConferma.Size = new System.Drawing.Size(75, 23);
            this.btnConferma.TabIndex = 7;
            this.btnConferma.Text = "Conferma";
            this.btnConferma.UseVisualStyleBackColor = true;
            this.btnConferma.Click += new System.EventHandler(this.btnConferma_Click);
            // 
            // btnAnnulla
            // 
            this.btnAnnulla.Location = new System.Drawing.Point(351, 298);
            this.btnAnnulla.Name = "btnAnnulla";
            this.btnAnnulla.Size = new System.Drawing.Size(75, 23);
            this.btnAnnulla.TabIndex = 8;
            this.btnAnnulla.Text = "Annulla";
            this.btnAnnulla.UseVisualStyleBackColor = true;
            this.btnAnnulla.Click += new System.EventHandler(this.btnAnnulla_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(203, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Note";
            // 
            // tbNote
            // 
            this.tbNote.Location = new System.Drawing.Point(206, 25);
            this.tbNote.Name = "tbNote";
            this.tbNote.Size = new System.Drawing.Size(170, 20);
            this.tbNote.TabIndex = 2;
            // 
            // btnLoadExcel
            // 
            this.btnLoadExcel.Location = new System.Drawing.Point(386, 20);
            this.btnLoadExcel.Name = "btnLoadExcel";
            this.btnLoadExcel.Size = new System.Drawing.Size(121, 30);
            this.btnLoadExcel.TabIndex = 11;
            this.btnLoadExcel.Text = "Carica elenco da .xlsx";
            this.btnLoadExcel.UseVisualStyleBackColor = true;
            this.btnLoadExcel.Click += new System.EventHandler(this.btnLoadExcel_Click);
            // 
            // cbBatterie
            // 
            this.cbBatterie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBatterie.FormattingEnabled = true;
            this.cbBatterie.Location = new System.Drawing.Point(386, 53);
            this.cbBatterie.Name = "cbBatterie";
            this.cbBatterie.Size = new System.Drawing.Size(121, 21);
            this.cbBatterie.TabIndex = 12;
            this.cbBatterie.SelectedValueChanged += new System.EventHandler(this.cbBatterie_SelectedValueChanged);
            // 
            // frmBatteria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 327);
            this.Controls.Add(this.cbBatterie);
            this.Controls.Add(this.btnLoadExcel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNote);
            this.Controls.Add(this.btnAnnulla);
            this.Controls.Add(this.btnConferma);
            this.Controls.Add(this.dgvBatteria);
            this.Controls.Add(this.btnRimuovi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAggiungi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNome);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmBatteria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aggiungi Batteria Atleti";
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatteria)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAggiungi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRimuovi;
        private System.Windows.Forms.DataGridView dgvBatteria;
        private System.Windows.Forms.Button btnConferma;
        private System.Windows.Forms.Button btnAnnulla;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAtleta;
        private System.Windows.Forms.DataGridViewTextBoxColumn Note;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNote;
        private System.Windows.Forms.Button btnLoadExcel;
        private System.Windows.Forms.OpenFileDialog ofdBatteria;
        private System.Windows.Forms.ComboBox cbBatterie;
    }
}